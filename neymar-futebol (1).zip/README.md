# Neymar Futebol
Futebol 1x1 para 2 jogadores no mesmo celular (Kotlin + OpenGL ES 2.0).
Modelo 3D: "Neymar 3d model" por sulavkhdka (CC BY 4.0) - https://sketchfab.com/3d-models/neymar-3d-model-c0ecd78392b74516bfe9db1d8f0f0d35
