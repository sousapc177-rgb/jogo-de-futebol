package com.futebol.neymar

import kotlin.math.*

class Game {
    companion object {
        const val MENU = 0
        const val KICKOFF = 1
        const val PLAY = 2
        const val GOAL = 3
        const val END = 4
        const val HL = 12f      // metade do comprimento do campo
        const val HW = 7f       // metade da largura
        const val GOALW = 2.4f  // metade da largura do gol
        const val GOALD = 2f    // profundidade do gol
        const val GOALH = 1.7f  // altura do gol
        const val BR = 0.3f     // raio da bola
        const val SPEED = 5.4f
        const val PIF = 3.1415927f
    }

    @Volatile var state = MENU
    @Volatile var matchSeconds = 120
    @Volatile var pendingStart = false

    val joyX = FloatArray(2)
    val joyY = FloatArray(2)
    val kick = BooleanArray(2)
    val score = IntArray(2)

    var timeLeft = 0f
    var stateTimer = 0f
    var time = 0f
    var lastScorer = -1

    val px = floatArrayOf(-5f, 5f)
    val pz = floatArrayOf(0f, 0f)
    val vx = FloatArray(2)
    val vz = FloatArray(2)
    val yaw = floatArrayOf(90f, -90f)
    val kickAnim = FloatArray(2)
    val runPhase = FloatArray(2)

    var bx = 0f
    var by = BR
    var bz = 0f
    var bvx = 0f
    var bvy = 0f
    var bvz = 0f

    private fun resetPositions() {
        px[0] = -5f; pz[0] = 0f; yaw[0] = 90f
        px[1] = 5f; pz[1] = 0f; yaw[1] = -90f
        for (i in 0..1) { vx[i] = 0f; vz[i] = 0f; kickAnim[i] = 0f }
        bx = 0f; by = BR; bz = 0f
        bvx = 0f; bvy = 0f; bvz = 0f
    }

    private fun startMatch() {
        score[0] = 0; score[1] = 0
        timeLeft = matchSeconds.toFloat()
        resetPositions()
        lastScorer = -1
        state = KICKOFF
        stateTimer = 3f
    }

    fun update(dt0: Float) {
        val dt = min(dt0, 0.05f)
        time += dt
        if (pendingStart) { pendingStart = false; startMatch() }
        val st = state
        if (st == KICKOFF) {
            movePlayers(dt)
            stateTimer -= dt
            if (stateTimer <= 0f) state = PLAY
        } else if (st == PLAY) {
            movePlayers(dt)
            for (p in 0..1) {
                if (kick[p]) { kick[p] = false; tryKick(p) }
            }
            ballPhysics(dt / 2f)
            ballPhysics(dt / 2f)
            timeLeft -= dt
            if (state == PLAY && timeLeft <= 0f) { timeLeft = 0f; state = END }
        } else if (st == GOAL) {
            for (p in 0..1) {
                val f = max(0f, 1f - 6f * dt)
                vx[p] *= f; vz[p] *= f
            }
            ballPhysics(dt / 2f)
            ballPhysics(dt / 2f)
            stateTimer -= dt
            if (stateTimer <= 0f) { resetPositions(); state = KICKOFF; stateTimer = 2f }
        }
        if (state != PLAY) { kick[0] = false; kick[1] = false }
        for (p in 0..1) if (kickAnim[p] > 0f) kickAnim[p] = max(0f, kickAnim[p] - dt)
    }

    private fun movePlayers(dt: Float) {
        for (p in 0..1) {
            val tx = joyX[p] * SPEED
            val tz = joyY[p] * SPEED
            val k = min(1f, 10f * dt)
            vx[p] += (tx - vx[p]) * k
            vz[p] += (tz - vz[p]) * k
            px[p] += vx[p] * dt
            pz[p] += vz[p] * dt
            px[p] = px[p].coerceIn(-HL - 0.8f, HL + 0.8f)
            pz[p] = pz[p].coerceIn(-HW - 0.8f, HW + 0.8f)
            val sp = hypot(vx[p], vz[p])
            if (sp > 0.6f) {
                val target = atan2(vx[p], vz[p]) * 180f / PIF
                var d = target - yaw[p]
                while (d > 180f) d -= 360f
                while (d < -180f) d += 360f
                yaw[p] += d * min(1f, 14f * dt)
                runPhase[p] += sp * dt * 2.0f
            }
        }
        val dx = px[1] - px[0]
        val dz = pz[1] - pz[0]
        val d = hypot(dx, dz)
        if (d < 0.8f && d > 0.0001f) {
            val push = (0.8f - d) / 2f
            val nx = dx / d
            val nz = dz / d
            px[0] -= nx * push; pz[0] -= nz * push
            px[1] += nx * push; pz[1] += nz * push
        }
    }

    private fun tryKick(p: Int) {
        kickAnim[p] = 0.3f
        val d = hypot(bx - px[p], bz - pz[p])
        if (d < 1.5f && by < 1.3f) {
            val a = yaw[p] * PIF / 180f
            bvx = sin(a) * 15f + vx[p] * 0.3f
            bvz = cos(a) * 15f + vz[p] * 0.3f
            bvy = 3.2f
        }
    }

    private fun ballPhysics(dt: Float) {
        bvy -= 22f * dt
        bx += bvx * dt
        by += bvy * dt
        bz += bvz * dt
        if (by < BR) {
            by = BR
            bvy = if (bvy < -2f) -bvy * 0.55f else 0f
        }
        val f = if (by <= BR + 0.02f) exp(-1.1f * dt) else exp(-0.1f * dt)
        bvx *= f; bvz *= f

        // jogadores empurram a bola
        for (p in 0..1) {
            val dx = bx - px[p]
            val dz = bz - pz[p]
            val d = hypot(dx, dz)
            val r = 0.55f
            if (d < r && by < 1.1f) {
                val nx = if (d > 0.0001f) dx / d else 1f
                val nz = if (d > 0.0001f) dz / d else 0f
                bx = px[p] + nx * r
                bz = pz[p] + nz * r
                val rel = (bvx - vx[p]) * nx + (bvz - vz[p]) * nz
                if (rel < 0f) {
                    bvx -= 1.4f * rel * nx
                    bvz -= 1.4f * rel * nz
                }
            }
        }

        // paredes laterais (dentro do gol a rede segura a bola)
        val inGoalX = abs(bx) > HL + 0.1f
        val zLim = if (inGoalX) GOALW else HW
        if (bz > zLim - BR) { bz = zLim - BR; bvz = -abs(bvz) * 0.6f }
        if (bz < -zLim + BR) { bz = -zLim + BR; bvz = abs(bvz) * 0.6f }

        // linha de fundo: so entra pela boca do gol
        val open = abs(bz) < GOALW - BR && by < GOALH - BR
        val ax = abs(bx)
        if (ax > HL - BR && ax < HL + 1f && !open) {
            bx = sign(bx) * (HL - BR)
            bvx = -bvx * 0.6f
        }
        if (abs(bx) > HL + GOALD - BR) {
            bx = sign(bx) * (HL + GOALD - BR)
            bvx = -bvx * 0.4f
        }

        if (state == PLAY && abs(bx) > HL + 0.1f) {
            val s = if (bx > 0f) 0 else 1
            score[s]++
            lastScorer = s
            state = GOAL
            stateTimer = 3f
        }
    }
}
