package com.futebol.neymar

import kotlin.math.*
import kotlin.random.Random

class Game {
    companion object {
        const val MENU = 0
        const val KICKOFF = 1
        const val PLAY = 2
        const val GOAL = 3
        const val END = 4
        const val CONTROLS = 5
        const val TEAMSEL = 6
        const val TEAMS = 6     // 0 Santos, 1 Flamengo, 2 Real Madrid, 3 Barcelona, 4 PSG, 5 Arsenal
        const val HL = 12f      // metade do comprimento do campo
        const val HW = 7f       // metade da largura
        const val GOALW = 2.4f  // metade da largura do gol
        const val GOALD = 2f    // profundidade do gol
        const val GOALH = 1.7f  // altura do gol
        const val BR = 0.3f     // raio da bola
        const val SPEED = 5.4f
        const val PIF = 3.1415927f
    }

    @Volatile var state = MENU
    @Volatile var matchSeconds = 120
    @Volatile var pendingStart = false
    @Volatile var vsAI = false

    // entradas: toque
    val joyX = FloatArray(2)
    val joyY = FloatArray(2)
    val kickTouch = BooleanArray(2)
    // entradas: controle (Xbox / PS5)
    val kickBtn = BooleanArray(2)
    val kickTrig = BooleanArray(2)
    val stickX = FloatArray(2)
    val stickY = FloatArray(2)
    val hatX = FloatArray(2)
    val hatY = FloatArray(2)
    val keyDX = FloatArray(2)
    val keyDY = FloatArray(2)

    // controles conectados, na ordem em que conectaram (1o = J1 vermelho, 2o = J2 azul)
    val pads = ArrayList<Int>()
    val padNames = HashMap<Int, String>()

    fun addPad(id: Int, name: String) {
        synchronized(pads) {
            if (!pads.contains(id)) { pads.add(id); padNames[id] = name }
        }
    }

    fun removePad(id: Int) {
        synchronized(pads) { pads.remove(id); padNames.remove(id) }
    }

    fun retainPads(valid: List<Int>) {
        synchronized(pads) { pads.retainAll(valid) }
    }

    fun padIndex(id: Int): Int = synchronized(pads) { pads.indexOf(id) }

    fun padFor(p: Int): Boolean = !(vsAI && p == 1) && synchronized(pads) { p < pads.size }

    fun padName(p: Int): String = synchronized(pads) {
        if (p < pads.size) (padNames[pads[p]] ?: "Controle") else ""
    }

    fun clearPadState() {
        for (i in 0..1) {
            kickBtn[i] = false; kickTrig[i] = false
            stickX[i] = 0f; stickY[i] = 0f
            hatX[i] = 0f; hatY[i] = 0f
            keyDX[i] = 0f; keyDY[i] = 0f
        }
    }

    val score = IntArray(2)

    var timeLeft = 0f
    var stateTimer = 0f
    var time = 0f
    var lastScorer = -1

    val px = floatArrayOf(-5f, 5f)
    val pz = floatArrayOf(0f, 0f)
    val vx = FloatArray(2)
    val vz = FloatArray(2)
    val yaw = floatArrayOf(90f, -90f)
    val kickAnim = FloatArray(2)
    val runPhase = FloatArray(2)
    val charge = FloatArray(2)
    private val wasHeld = BooleanArray(2)
    private val armed = BooleanArray(2)
    val pressing = BooleanArray(2)
    private var owner = -1            // quem esta com a bola no pe (-1 = ninguem)
    private val pickCd = FloatArray(2)
    private var protect = 0f

    // posicoes projetadas na tela (0..1) para o HUD desenhar cursor, seta e barra
    val headX = FloatArray(2)
    val headY = FloatArray(2)
    val footX = FloatArray(2)
    val footY = FloatArray(2)
    val aheadX = FloatArray(2)
    val aheadY = FloatArray(2)

    var bx = 0f
    var by = BR
    var bz = 0f
    var bvx = 0f
    var bvy = 0f
    var bvz = 0f

    // IA
    private var aiX = 0f
    private var aiZ = 0f
    private var aiCool = 1f

    private fun resetPositions() {
        px[0] = -5f; pz[0] = 0f; yaw[0] = 90f
        px[1] = 5f; pz[1] = 0f; yaw[1] = -90f
        for (i in 0..1) { vx[i] = 0f; vz[i] = 0f; kickAnim[i] = 0f; charge[i] = 0f; wasHeld[i] = false }
        bx = 0f; by = BR; bz = 0f
        bvx = 0f; bvy = 0f; bvz = 0f
        aiX = 0f; aiZ = 0f; aiCool = 1f
        owner = -1; protect = 0f
        for (i in 0..1) { pickCd[i] = 0f; armed[i] = false; pressing[i] = false }
    }

    // times: 0 = Santos FC, 1 = Flamengo, 2 = Real Madrid, 3 = Barcelona
    val team = intArrayOf(0, 1)
    var selecting = 0          // quem esta escolhendo o time agora (0 = J1, 1 = J2 ou CPU)
    @Volatile var cursor = 0

    fun enterTeamSelect(ai: Boolean) {
        vsAI = ai
        score[0] = 0; score[1] = 0
        resetPositions()
        selecting = 0
        cursor = team[0]
        state = TEAMSEL
    }

    fun moveCursor(d: Int) {
        cursor = (cursor + d + TEAMS) % TEAMS
    }

    /** Confirma o time sob o cursor: o J1 escolhe e passa pro J2; o J2 escolhe e vai pros controles. */
    fun confirmTeam() {
        if (state != TEAMSEL) return
        if (selecting == 1 && cursor == team[0]) return
        team[selecting] = cursor
        if (selecting == 0) {
            selecting = 1
            cursor = if (team[1] != team[0]) team[1] else (team[0] + 1) % TEAMS
        } else {
            state = CONTROLS
        }
    }

    /** Volta um passo. Retorna true se deve sair pro menu. */
    fun backTeam(): Boolean {
        if (selecting == 1) {
            selecting = 0
            cursor = team[0]
            return false
        }
        return true
    }

    fun toControls() { state = CONTROLS }

    /** Entra na tela de controles antes da partida. */
    fun enterControls(ai: Boolean) {
        vsAI = ai
        score[0] = 0; score[1] = 0
        resetPositions()
        state = CONTROLS
    }

    private fun startMatch() {
        score[0] = 0; score[1] = 0
        timeLeft = matchSeconds.toFloat()
        resetPositions()
        lastScorer = -1
        state = KICKOFF
        stateTimer = 3f
    }

    fun update(dt0: Float) {
        val dt = min(dt0, 0.05f)
        time += dt
        if (pendingStart) { pendingStart = false; startMatch() }
        val st = state
        if (st == KICKOFF) {
            aiX = 0f; aiZ = 0f
            movePlayers(dt)
            stateTimer -= dt
            if (stateTimer <= 0f) state = PLAY
        } else if (st == PLAY) {
            if (vsAI) aiThink(dt) else { aiX = 0f; aiZ = 0f }
            handleKicks(dt)
            movePlayers(dt)
            updatePossession(dt)
            if (owner >= 0) {
                val o = owner
                val ex = bx
                val ez = bz
                ballWalls()
                if (owner >= 0 && hypot(bx - ex, bz - ez) > 0.3f) { owner = -1; pickCd[o] = 0.4f }
            } else {
                ballPhysics(dt / 2f)
                ballPhysics(dt / 2f)
            }
            timeLeft -= dt
            if (state == PLAY && timeLeft <= 0f) { timeLeft = 0f; state = END }
        } else if (st == GOAL) {
            for (p in 0..1) {
                val f = max(0f, 1f - 6f * dt)
                vx[p] *= f; vz[p] *= f
            }
            ballPhysics(dt / 2f)
            ballPhysics(dt / 2f)
            stateTimer -= dt
            if (stateTimer <= 0f) { resetPositions(); state = KICKOFF; stateTimer = 2f }
        }
        if (state != PLAY) {
            for (i in 0..1) { charge[i] = 0f; wasHeld[i] = false; armed[i] = false; pressing[i] = false }
        }
        for (p in 0..1) if (kickAnim[p] > 0f) kickAnim[p] = max(0f, kickAnim[p] - dt)
    }

    private fun handleKicks(dt: Float) {
        for (p in 0..1) {
            if (vsAI && p == 1) continue
            val held = kickTouch[p] || kickBtn[p] || kickTrig[p]
            val oppOwns = owner >= 0 && owner != p
            pressing[p] = held && oppOwns
            if (held && !oppOwns) {
                armed[p] = true
                charge[p] = min(1f, charge[p] + dt / 0.9f)
            } else if (held) {
                armed[p] = false
                charge[p] = 0f
            } else {
                if (armed[p]) shoot(p, 0.3f + 0.7f * charge[p])
                armed[p] = false
                charge[p] = 0f
            }
        }
    }

    private fun movePlayers(dt: Float) {
        for (p in 0..1) {
            var jx: Float
            var jy: Float
            if (pressing[p] && owner >= 0 && owner != p) {
                // segurando o botao sem a bola: persegue quem esta com ela
                val ddx = px[owner] - px[p]
                val ddz = pz[owner] - pz[p]
                val dl = max(0.001f, hypot(ddx, ddz))
                jx = ddx / dl; jy = ddz / dl
            } else if (vsAI && p == 1) {
                jx = aiX; jy = aiZ
            } else if (padFor(p)) {
                val sx = stickX[p]
                val sy = stickY[p]
                if (hypot(sx, sy) > 0.01f) {
                    jx = sx; jy = sy
                } else {
                    jx = hatX[p] + keyDX[p]
                    jy = hatY[p] + keyDY[p]
                }
            } else {
                jx = joyX[p]; jy = joyY[p]
            }
            val mag = hypot(jx, jy)
            if (mag > 1f) { jx /= mag; jy /= mag }
            val speedMul = if (vsAI && p == 1) 0.88f else 1f
            val tx = jx * SPEED * speedMul
            val tz = jy * SPEED * speedMul
            val k = min(1f, 10f * dt)
            vx[p] += (tx - vx[p]) * k
            vz[p] += (tz - vz[p]) * k
            px[p] += vx[p] * dt
            pz[p] += vz[p] * dt
            px[p] = px[p].coerceIn(-HL - 0.8f, HL + 0.8f)
            pz[p] = pz[p].coerceIn(-HW - 0.8f, HW + 0.8f)
            val sp = hypot(vx[p], vz[p])
            if (sp > 0.6f) {
                val target = atan2(vx[p], vz[p]) * 180f / PIF
                var d = target - yaw[p]
                while (d > 180f) d -= 360f
                while (d < -180f) d += 360f
                yaw[p] += d * min(1f, 14f * dt)
                runPhase[p] += sp * dt * 2.0f
            }
        }
        val dx = px[1] - px[0]
        val dz = pz[1] - pz[0]
        val d = hypot(dx, dz)
        if (d < 0.8f && d > 0.0001f) {
            val push = (0.8f - d) / 2f
            val nx = dx / d
            val nz = dz / d
            px[0] -= nx * push; pz[0] -= nz * push
            px[1] += nx * push; pz[1] += nz * push
        }
    }

    private fun aiThink(dt: Float) {
        val p = 1
        // J2 (CPU) ataca o gol da esquerda (x = -HL)
        var gx = -HL - bx
        var gz = 0f - bz
        val gl = max(0.001f, hypot(gx, gz))
        gx /= gl; gz /= gl
        val toBall = hypot(bx - px[p], bz - pz[p])
        aiCool -= dt
        pressing[p] = owner == 0
        if (owner == 0) {
            // jogador esta com a bola: CPU vai atras e rouba
            val mx = px[0] - px[p]
            val mz = pz[0] - pz[p]
            val ml = max(0.001f, hypot(mx, mz))
            aiX = mx / ml; aiZ = mz / ml
        } else if (toBall < 1.1f) {
            // com a bola: conduz pro gol e chuta quando chega perto
            aiX = gx; aiZ = gz
            val ahead = (bx - px[p]) * gx + (bz - pz[p]) * gz
            val dGoal = hypot(px[p] + HL, pz[p])
            if (ahead > 0f && dGoal < 8f && aiCool <= 0f) {
                val jitter = (Random.nextFloat() - 0.5f) * 0.3f
                yaw[p] = (atan2(gx, gz) + jitter) * 180f / PIF
                shoot(p, 0.55f + Random.nextFloat() * 0.35f)
                aiCool = 0.7f + Random.nextFloat() * 0.7f
            }
        } else {
            // vai pro ponto atras da bola (do lado oposto ao gol)
            var mx = (bx - gx * 0.8f) - px[p]
            var mz = (bz - gz * 0.8f) - pz[p]
            val ml = max(0.001f, hypot(mx, mz))
            mx /= ml; mz /= ml
            aiX = mx; aiZ = mz
        }
    }

    /** Bola no pe: quem chega perto da bola domina; quem segura o botao rouba. */
    private fun updatePossession(dt: Float) {
        for (p in 0..1) pickCd[p] = max(0f, pickCd[p] - dt)
        protect = max(0f, protect - dt)
        if (owner >= 0) {
            val d = 1 - owner
            val near = min(hypot(px[d] - bx, pz[d] - bz), hypot(px[d] - px[owner], pz[d] - pz[owner]))
            if (protect <= 0f && pressing[d] && near < 0.95f) {
                pickCd[owner] = 0.5f
                owner = d
                protect = 0.8f
            }
            val o = owner
            val a = yaw[o] * PIF / 180f
            val dist = 0.72f + 0.10f * sin(runPhase[o])
            bx = px[o] + sin(a) * dist
            bz = pz[o] + cos(a) * dist
            by = BR
            bvx = vx[o]; bvz = vz[o]; bvy = 0f
        } else {
            var best = -1
            var bestD = 0.75f
            for (p in 0..1) {
                if (pickCd[p] > 0f) continue
                val dd = hypot(bx - px[p], bz - pz[p])
                val rel = hypot(bvx - vx[p], bvz - vz[p])
                if (dd < bestD && by < 0.8f && rel < 11f) { best = p; bestD = dd }
            }
            if (best >= 0) { owner = best; protect = 0.5f }
        }
    }

    private fun shoot(p: Int, power: Float) {
        kickAnim[p] = 0.3f
        val d = hypot(bx - px[p], bz - pz[p])
        if (owner == p || (owner < 0 && d < 1.5f && by < 1.3f)) {
            val a = yaw[p] * PIF / 180f
            val speed = 6f + 12f * power
            bvx = sin(a) * speed + vx[p] * 0.3f
            bvz = cos(a) * speed + vz[p] * 0.3f
            bvy = 1.5f + 3f * power
            owner = -1
            pickCd[p] = 0.45f
        }
    }

    private fun ballPhysics(dt: Float) {
        bvy -= 22f * dt
        bx += bvx * dt
        by += bvy * dt
        bz += bvz * dt
        if (by < BR) {
            by = BR
            bvy = if (bvy < -2f) -bvy * 0.55f else 0f
        }
        val f = if (by <= BR + 0.02f) exp(-1.1f * dt) else exp(-0.1f * dt)
        bvx *= f; bvz *= f

        // jogadores empurram a bola
        for (p in 0..1) {
            val dx = bx - px[p]
            val dz = bz - pz[p]
            val d = hypot(dx, dz)
            val r = 0.55f
            if (d < r && by < 1.1f) {
                val nx = if (d > 0.0001f) dx / d else 1f
                val nz = if (d > 0.0001f) dz / d else 0f
                bx = px[p] + nx * r
                bz = pz[p] + nz * r
                val rel = (bvx - vx[p]) * nx + (bvz - vz[p]) * nz
                if (rel < 0f) {
                    bvx -= 1.4f * rel * nx
                    bvz -= 1.4f * rel * nz
                }
            }
        }

        ballWalls()
    }

    private fun ballWalls() {
        // paredes laterais (dentro do gol a rede segura a bola)
        val inGoalX = abs(bx) > HL + 0.1f
        val zLim = if (inGoalX) GOALW else HW
        if (bz > zLim - BR) { bz = zLim - BR; bvz = -abs(bvz) * 0.6f }
        if (bz < -zLim + BR) { bz = -zLim + BR; bvz = abs(bvz) * 0.6f }

        // linha de fundo: so entra pela boca do gol
        val open = abs(bz) < GOALW - BR && by < GOALH - BR
        val ax = abs(bx)
        if (ax > HL - BR && ax < HL + 1f && !open) {
            bx = sign(bx) * (HL - BR)
            bvx = -bvx * 0.6f
        }
        if (abs(bx) > HL + GOALD - BR) {
            bx = sign(bx) * (HL + GOALD - BR)
            bvx = -bvx * 0.4f
        }

        if (state == PLAY && abs(bx) > HL + 0.1f) {
            val s = if (bx > 0f) 0 else 1
            score[s]++
            lastScorer = s
            state = GOAL
            owner = -1
            stateTimer = 3f
        }
    }
}
