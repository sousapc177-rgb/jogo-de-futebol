package com.futebol.neymar

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.ceil
import kotlin.math.hypot

class HudView(ctx: Context, private val game: Game, private val onMenu: () -> Unit) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val joyId = intArrayOf(-1, -1)
    private val ox = FloatArray(2)
    private val oy = FloatArray(2)
    private val cx = FloatArray(2)
    private val cy = FloatArray(2)
    private val kickId = intArrayOf(-1, -1)
    private val rematchBtn = RectF()
    private val menuBtn = RectF()
    private val rect = RectF()
    private val c1 = 0xFFE53935.toInt()
    private val c2 = 0xFF1E88E5.toInt()

    fun reset() {
        for (i in 0..1) {
            joyId[i] = -1; kickId[i] = -1
            game.joyX[i] = 0f; game.joyY[i] = 0f
        }
    }

    private fun joyR() = height * 0.17f
    private fun kx(i: Int) = if (i == 0) width * 0.40f else width * 0.60f
    private fun ky() = height * 0.80f
    private fun kr() = height * 0.10f
    private fun hx(i: Int) = if (i == 0) width * 0.13f else width * 0.87f
    private fun hy() = height * 0.72f
    private fun teamColor(i: Int) = if (i == 0) c1 else c2

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = size
        p.color = color
        p.setShadowLayer(size * 0.06f, 0f, size * 0.04f, 0xAA000000.toInt())
        c.drawText(s, x, y, p)
        p.clearShadowLayer()
    }

    override fun onDraw(c: Canvas) {
        val st = game.state
        if (st == Game.MENU) return
        val w = width.toFloat()
        val h = height.toFloat()

        // placar
        rect.set(w * 0.30f, h * 0.02f, w * 0.70f, h * 0.20f)
        p.style = Paint.Style.FILL
        p.color = 0x99000000.toInt()
        c.drawRoundRect(rect, h * 0.04f, h * 0.04f, p)
        txt(c, "J1", w * 0.35f, h * 0.115f, h * 0.06f, c1)
        txt(c, "J2", w * 0.65f, h * 0.115f, h * 0.06f, c2)
        txt(c, "${game.score[0]} - ${game.score[1]}", w * 0.5f, h * 0.125f, h * 0.095f, 0xFFFFFFFF.toInt())
        val secs = ceil(game.timeLeft).toInt()
        txt(c, String.format("%d:%02d", secs / 60, secs % 60), w * 0.5f, h * 0.185f, h * 0.05f, 0xFFFFD500.toInt())

        if (st != Game.END) drawControls(c)

        if (st == Game.KICKOFF) {
            val n = ceil(game.stateTimer).toInt().coerceIn(1, 3)
            txt(c, n.toString(), w * 0.5f, h * 0.55f, h * 0.28f, 0xFFFFFFFF.toInt())
        } else if (st == Game.GOAL) {
            txt(c, "GOOOL!", w * 0.5f, h * 0.50f, h * 0.22f, 0xFFFFD500.toInt())
            if (game.lastScorer >= 0) {
                txt(c, "J" + (game.lastScorer + 1) + " marcou!", w * 0.5f, h * 0.62f, h * 0.07f, teamColor(game.lastScorer))
            }
        } else if (st == Game.END) {
            p.style = Paint.Style.FILL
            p.color = 0xBB000000.toInt()
            c.drawRect(0f, 0f, w, h, p)
            txt(c, "FIM DE JOGO", w * 0.5f, h * 0.28f, h * 0.12f, 0xFFFFFFFF.toInt())
            txt(c, "${game.score[0]} - ${game.score[1]}", w * 0.5f, h * 0.50f, h * 0.16f, 0xFFFFD500.toInt())
            val s0 = game.score[0]
            val s1 = game.score[1]
            if (s0 == s1) txt(c, "EMPATE!", w * 0.5f, h * 0.61f, h * 0.07f, 0xFFFFFFFF.toInt())
            else {
                val win = if (s0 > s1) 0 else 1
                txt(c, "J" + (win + 1) + " GANHOU!", w * 0.5f, h * 0.61f, h * 0.07f, teamColor(win))
            }
            val bw = w * 0.22f
            val bh = h * 0.14f
            val gap = w * 0.03f
            rematchBtn.set(w * 0.5f - bw - gap / 2f, h * 0.68f, w * 0.5f - gap / 2f, h * 0.68f + bh)
            menuBtn.set(w * 0.5f + gap / 2f, h * 0.68f, w * 0.5f + gap / 2f + bw, h * 0.68f + bh)
            p.style = Paint.Style.FILL
            p.color = 0xFF2E9E3F.toInt()
            c.drawRoundRect(rematchBtn, bh / 2f, bh / 2f, p)
            p.color = 0xFF555555.toInt()
            c.drawRoundRect(menuBtn, bh / 2f, bh / 2f, p)
            txt(c, "REVANCHE", rematchBtn.centerX(), rematchBtn.centerY() + h * 0.02f, h * 0.06f, 0xFFFFFFFF.toInt())
            txt(c, "MENU", menuBtn.centerX(), menuBtn.centerY() + h * 0.02f, h * 0.06f, 0xFFFFFFFF.toInt())
        }
    }

    private fun drawControls(c: Canvas) {
        val r = joyR()
        for (i in 0..1) {
            val col = teamColor(i)
            p.style = Paint.Style.STROKE
            p.strokeWidth = height * 0.008f
            if (joyId[i] == -1) {
                p.color = (col and 0x00FFFFFF) or 0x55000000
                c.drawCircle(hx(i), hy(), r, p)
                txt(c, "J" + (i + 1), hx(i), hy() + height * 0.025f, height * 0.07f, (col and 0x00FFFFFF) or 0x66000000)
            } else {
                p.color = (col and 0x00FFFFFF) or 0x88000000.toInt()
                c.drawCircle(ox[i], oy[i], r, p)
                p.style = Paint.Style.FILL
                p.color = (col and 0x00FFFFFF) or 0xAA000000.toInt()
                c.drawCircle(cx[i], cy[i], r * 0.4f, p)
            }
            // botao chutar
            p.style = Paint.Style.FILL
            val pressed = kickId[i] != -1
            p.color = (col and 0x00FFFFFF) or (if (pressed) 0xDD000000 else 0x88000000).toInt()
            c.drawCircle(kx(i), ky(), kr(), p)
            txt(c, "CHUTAR", kx(i), ky() + kr() * 0.14f, kr() * 0.38f, 0xFFFFFFFF.toInt())
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val st = game.state
        if (st == Game.END) {
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                if (rematchBtn.contains(e.x, e.y)) game.pendingStart = true
                else if (menuBtn.contains(e.x, e.y)) onMenu()
            }
            return true
        }
        if (st == Game.MENU) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> reset()
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        for (i in 0..1) {
            if (hypot(x - kx(i), y - ky()) < kr() * 1.3f) {
                kickId[i] = id
                game.kick[i] = true
                return
            }
        }
        val i = if (x < width * 0.5f) 0 else 1
        if (joyId[i] == -1) {
            joyId[i] = id
            ox[i] = x; oy[i] = y; cx[i] = x; cy[i] = y
            game.joyX[i] = 0f; game.joyY[i] = 0f
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        for (i in 0..1) {
            if (joyId[i] == id) {
                val r = joyR()
                var dx = x - ox[i]
                var dy = y - oy[i]
                val len = hypot(dx, dy)
                if (len > r) { dx = dx / len * r; dy = dy / len * r }
                cx[i] = ox[i] + dx
                cy[i] = oy[i] + dy
                if (len < r * 0.15f) { game.joyX[i] = 0f; game.joyY[i] = 0f }
                else { game.joyX[i] = dx / r; game.joyY[i] = dy / r }
            }
        }
    }

    private fun up(id: Int) {
        for (i in 0..1) {
            if (joyId[i] == id) { joyId[i] = -1; game.joyX[i] = 0f; game.joyY[i] = 0f }
            if (kickId[i] == id) kickId[i] = -1
        }
    }
}
