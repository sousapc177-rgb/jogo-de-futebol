package com.futebol.neymar

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val game = Game()
    private lateinit var glView: GLSurfaceView
    private lateinit var hud: HudView
    private lateinit var menu: View
    private lateinit var timeText: TextView
    private lateinit var timeChip: TextView
    private val times = intArrayOf(60, 120, 180)
    private var timeIdx = 1

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val root = FrameLayout(this)

        hud = HudView(this, game) { showMenu() }
        hud.visibility = View.GONE

        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        glView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        glView.setRenderer(GameRenderer(this, game, hud))

        menu = buildMenu()

        root.addView(glView, FrameLayout.LayoutParams(-1, -1))
        root.addView(hud, FrameLayout.LayoutParams(-1, -1))
        root.addView(menu, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    // ------------------------------------------------------------ menu

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = true): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        return t
    }

    private fun circle(text: String, color: Int, sizeDp: Int): TextView {
        val t = tv(text, 12f, Color.WHITE)
        t.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        t.background = g
        t.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return t
    }

    private fun card(bg: Int, weight: Float, onClick: (() -> Unit)?): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), dp(10), dp(12), dp(10))
        c.background = rounded(bg, 6)
        val lp = LinearLayout.LayoutParams(-1, 0, weight)
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        c.layoutParams = lp
        if (onClick != null) c.setOnClickListener { onClick() }
        return c
    }

    private fun buildMenu(): View {
        val root = FrameLayout(this)
        val cyan = 0xFF18C0E8.toInt()
        val red = 0xFFE53935.toInt()
        val blue = 0xFF1E88E5.toInt()
        val soft = 0xFFB0C4E8.toInt()
        val panel = 0xDD132B5C.toInt()
        val sw = resources.displayMetrics.widthPixels

        // barra de cima
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(12), dp(4), dp(12), dp(4))
        top.setBackgroundColor(0xBB061230.toInt())
        top.addView(circle("NJ", 0xFF1E6FE0.toInt(), 38))
        val nameBox = LinearLayout(this)
        nameBox.orientation = LinearLayout.VERTICAL
        nameBox.setPadding(dp(10), 0, 0, 0)
        nameBox.addView(tv("Neymar Jr", 14f, Color.WHITE))
        nameBox.addView(tv("Temporada 2026", 10f, soft, false))
        top.addView(nameBox)
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        timeChip = tv("", 13f, Color.WHITE)
        timeChip.gravity = Gravity.CENTER
        timeChip.setPadding(dp(14), dp(6), dp(14), dp(6))
        timeChip.background = rounded(0xFF12306B.toInt(), 16)
        timeChip.setOnClickListener { cycleTime() }
        top.addView(timeChip)
        val help = circle("?", 0xFF12306B.toInt(), 34)
        (help.layoutParams as LinearLayout.LayoutParams).leftMargin = dp(10)
        help.setOnClickListener { showControls() }
        top.addView(help)
        root.addView(top, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP))

        // cartoes
        val big = card(0xFF2F6BD8.toInt(), 2f) { startGame() }
        big.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF3A7BFF.toInt(), 0xFF1B3FA8.toInt())
        ).apply { cornerRadius = dp(6).toFloat() }
        big.gravity = Gravity.CENTER_VERTICAL
        big.addView(tv("JOGUE AGORA", 22f, Color.WHITE))
        val d = tv("Dois jogadores no mesmo celular. Bora ver quem e o craque!", 12f, Color.WHITE, false)
        d.setPadding(0, dp(4), 0, dp(8))
        big.addView(d)
        big.addView(tv("1 x 1", 28f, Color.WHITE))

        val next = card(0xFFF2F4F8.toInt(), 1.2f, null)
        next.addView(tv("PROXIMO JOGO", 11f, 0xFF556070.toInt()))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.addView(circle("J1", red, 40))
        val vs = tv("VS", 16f, 0xFF222B38.toInt())
        vs.setPadding(dp(16), 0, dp(16), 0)
        row.addView(vs)
        row.addView(circle("J2", blue, 40))
        row.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        next.addView(row)

        val tcard = card(panel, 1f) { cycleTime() }
        tcard.addView(tv("TEMPO DE JOGO", 12f, cyan))
        timeText = tv("2:00", 30f, Color.WHITE)
        tcard.addView(timeText)
        tcard.addView(tv("toque pra mudar", 10f, soft, false))

        val ex = card(panel, 1f) { finish() }
        ex.addView(tv("SAIR", 12f, cyan))
        ex.addView(tv("X", 30f, Color.WHITE))

        val colL = LinearLayout(this)
        colL.orientation = LinearLayout.VERTICAL
        colL.addView(big)
        colL.addView(next)
        val colR = LinearLayout(this)
        colR.orientation = LinearLayout.VERTICAL
        colR.addView(tcard)
        colR.addView(ex)
        val content = LinearLayout(this)
        content.orientation = LinearLayout.HORIZONTAL
        content.addView(colL, LinearLayout.LayoutParams(0, -1, 1.7f))
        content.addView(colR, LinearLayout.LayoutParams(0, -1, 1f))
        val clp = FrameLayout.LayoutParams(-1, -1)
        clp.leftMargin = sw * 38 / 100
        clp.rightMargin = dp(10)
        clp.topMargin = dp(60)
        clp.bottomMargin = dp(72)
        root.addView(content, clp)

        // barra de baixo
        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(0xEE0A1B3D.toInt())
        fun navItem(icon: String, label: String, action: () -> Unit): LinearLayout {
            val i = LinearLayout(this)
            i.orientation = LinearLayout.VERTICAL
            i.gravity = Gravity.CENTER
            i.addView(tv(icon, 20f, cyan))
            i.addView(tv(label, 10f, Color.WHITE))
            i.setOnClickListener { action() }
            i.layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            return i
        }
        nav.addView(navItem("\u25B6", "JOGAR") { startGame() })
        nav.addView(navItem("\u25F7", "TEMPO") { cycleTime() })
        nav.addView(navItem("\u2630", "CONTROLES") { showControls() })
        nav.addView(navItem("\u2605", "CREDITOS") { showCredits() })
        nav.addView(navItem("\u2715", "SAIR") { finish() })
        root.addView(nav, FrameLayout.LayoutParams(-1, dp(64), Gravity.BOTTOM))

        updateTime()
        return root
    }

    private fun cycleTime() {
        timeIdx = (timeIdx + 1) % times.size
        updateTime()
    }

    private fun updateTime() {
        val label = (times[timeIdx] / 60).toString() + ":00"
        timeChip.text = "TEMPO  $label"
        timeText.text = label
    }

    private fun showControls() {
        AlertDialog.Builder(this)
            .setTitle("Controles")
            .setMessage("J1 joga no lado esquerdo da tela e J2 no lado direito.\n\nArrasta o dedo pra correr e toca em CHUTAR quando a bola estiver perto.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showCredits() {
        AlertDialog.Builder(this)
            .setTitle("Creditos")
            .setMessage("Modelo 3D: \"Neymar 3d model\" por sulavkhdka (CC BY 4.0).")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun startGame() {
        game.matchSeconds = times[timeIdx]
        hud.reset()
        game.pendingStart = true
        menu.visibility = View.GONE
        hud.visibility = View.VISIBLE
    }

    private fun showMenu() {
        hud.reset()
        game.state = Game.MENU
        hud.visibility = View.GONE
        menu.visibility = View.VISIBLE
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (game.state != Game.MENU) showMenu() else finish()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glView.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }
}
