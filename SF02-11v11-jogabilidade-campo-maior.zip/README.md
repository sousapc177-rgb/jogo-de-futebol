# SF02 — atualização de gameplay

Esta versão parte do projeto SF02 fornecido e inclui alterações de gameplay e apresentação:

- Campo ampliado (dimensões internas e marcações atualizadas).
- Câmera mais afastada/alta para enquadrar o campo maior.
- Modelos dos 22 jogadores renderizados em escala maior.
- IA dos 20 companheiros com deslocamento de equipe mais perceptível, pressão à bola e abertura de linhas de passe.
- Botão PASSE reposicionado e aumentado no HUD.
- Passe direcionado ao companheiro mais avançado; quando a bola chega, o companheiro passa a ser o jogador controlado pelo joystick.

O projeto usa o mesmo arquivo de modelo `neymar.bin` e as texturas já existentes; não duplica os assets 3D.

## Compilação

O projeto está na raiz do repositório. O workflow `.github/workflows/build.yml` executa `gradle assembleDebug --no-daemon` e publica o APK em Artifacts.

A compilação Android completa precisa ser confirmada pelo GitHub Actions. A lógica `Game.kt` foi verificada com o compilador Kotlin local.
