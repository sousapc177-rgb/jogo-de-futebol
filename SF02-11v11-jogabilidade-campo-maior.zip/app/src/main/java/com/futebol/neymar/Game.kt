package com.futebol.neymar

import kotlin.math.*
import kotlin.random.Random

class Game {
    companion object {
        const val MENU = 0
        const val KICKOFF = 1
        const val PLAY = 2
        const val GOAL = 3
        const val END = 4
        const val CONTROLS = 5
        const val TEAMSEL = 6
        const val TEAMS = 8     // 0 Santos, 1 Flamengo, 2 Real Madrid, 3 Barcelona, 4 PSG, 5 Arsenal, 6 Bayern, 7 Dortmund
        const val HL = 17f      // metade do comprimento do campo (campo ampliado)
        const val HW = 10f      // metade da largura (campo ampliado)
        const val GOALW = 2.4f  // metade da largura do gol
        const val GOALD = 2f    // profundidade do gol
        const val GOALH = 1.7f  // altura do gol
        const val BR = 0.3f     // raio da bola
        const val SPEED = 5.4f
        const val PIF = 3.1415927f
    }

    @Volatile var state = MENU
    @Volatile var matchSeconds = 120
    @Volatile var pendingStart = false
    @Volatile var vsAI = false

    // entradas: toque
    val joyX = FloatArray(2)
    val joyY = FloatArray(2)
    val kickTouch = BooleanArray(2)
    val passTouch = BooleanArray(2)
    private val passWasDown = BooleanArray(2)
    // entradas: controle (Xbox / PS5)
    val kickBtn = BooleanArray(2)
    val kickTrig = BooleanArray(2)
    val stickX = FloatArray(2)
    val stickY = FloatArray(2)
    val hatX = FloatArray(2)
    val hatY = FloatArray(2)
    val keyDX = FloatArray(2)
    val keyDY = FloatArray(2)

    // controles conectados, na ordem em que conectaram (1o = J1 vermelho, 2o = J2 azul)
    val pads = ArrayList<Int>()
    val padNames = HashMap<Int, String>()

    fun addPad(id: Int, name: String) {
        synchronized(pads) {
            if (!pads.contains(id)) { pads.add(id); padNames[id] = name }
        }
    }

    fun removePad(id: Int) {
        synchronized(pads) { pads.remove(id); padNames.remove(id) }
    }

    fun retainPads(valid: List<Int>) {
        synchronized(pads) { pads.retainAll(valid) }
    }

    fun padIndex(id: Int): Int = synchronized(pads) { pads.indexOf(id) }

    fun padFor(p: Int): Boolean = !(vsAI && p == 1) && synchronized(pads) { p < pads.size }

    fun padName(p: Int): String = synchronized(pads) {
        if (p < pads.size) (padNames[pads[p]] ?: "Controle") else ""
    }

    fun clearPadState() {
        for (i in 0..1) {
            kickBtn[i] = false; kickTrig[i] = false
            stickX[i] = 0f; stickY[i] = 0f
            hatX[i] = 0f; hatY[i] = 0f
            keyDX[i] = 0f; keyDY[i] = 0f
        }
    }

    val score = IntArray(2)

    var timeLeft = 0f
    var stateTimer = 0f
    var time = 0f
    var lastScorer = -1

    val px = floatArrayOf(-5f, 5f)
    val pz = floatArrayOf(0f, 0f)
    val vx = FloatArray(2)
    val vz = FloatArray(2)
    val yaw = floatArrayOf(90f, -90f)
    val kickAnim = FloatArray(2)
    val runPhase = FloatArray(2)
    val charge = FloatArray(2)
    private val wasHeld = BooleanArray(2)
    private val armed = BooleanArray(2)
    val pressing = BooleanArray(2)
    private var owner = -1            // quem esta com a bola no pe (-1 = ninguem)
    private val pickCd = FloatArray(2)
    private var protect = 0f
    private var pendingPassMate = -1
    private var pendingPassX = 0f
    private var pendingPassZ = 0f

    // 10 companheiros por lado (além do jogador principal de cada time).
    // Os mesmos meshes/texturas são reutilizados para não duplicar assets.
    val mateX = FloatArray(20)
    val mateZ = FloatArray(20)
    val mateYaw = FloatArray(20)
    val mateRun = FloatArray(20)
    val matePhase = FloatArray(20)
    private val mateVx = FloatArray(20)
    private val mateVz = FloatArray(20)
    private val mateBaseX = FloatArray(20)
    private val mateBaseZ = FloatArray(20)

    // posicoes projetadas na tela (0..1) para o HUD desenhar cursor, seta e barra
    val headX = FloatArray(2)
    val headY = FloatArray(2)
    val footX = FloatArray(2)
    val footY = FloatArray(2)
    val aheadX = FloatArray(2)
    val aheadY = FloatArray(2)

    var bx = 0f
    var by = BR
    var bz = 0f
    var bvx = 0f
    var bvy = 0f
    var bvz = 0f

    // IA
    private var aiX = 0f
    private var aiZ = 0f
    private var aiCool = 1f

    private fun resetPositions() {
        px[0] = -6f; pz[0] = 0f; yaw[0] = 90f
        px[1] = 6f; pz[1] = 0f; yaw[1] = -90f
        for (i in 0..1) { vx[i] = 0f; vz[i] = 0f; kickAnim[i] = 0f; charge[i] = 0f; wasHeld[i] = false }
        bx = 0f; by = BR; bz = 0f
        bvx = 0f; bvy = 0f; bvz = 0f
        aiX = 0f; aiZ = 0f; aiCool = 1f
        owner = -1; protect = 0f
        pendingPassMate = -1
        val formationX = floatArrayOf(-12.8f, -9.8f, -9.8f, -9.8f, -9.8f, -5.8f, -5.8f, -2.2f, 1.2f, 1.2f)
        val formationZ = floatArrayOf(0f, -6.4f, -2.2f, 2.2f, 6.4f, -4.6f, 4.6f, 0f, -3.6f, 3.6f)
        for (side in 0..1) for (slot in 0..9) {
            val i = side * 10 + slot
            val dir = if (side == 0) 1f else -1f
            mateBaseX[i] = formationX[slot] * dir
            mateBaseZ[i] = formationZ[slot] * if (side == 0) 1f else -1f
            mateX[i] = mateBaseX[i]; mateZ[i] = mateBaseZ[i]
            mateYaw[i] = if (side == 0) 90f else -90f
            mateVx[i] = 0f; mateVz[i] = 0f; mateRun[i] = 0f; matePhase[i] = 0f
        }
        for (i in 0..1) { pickCd[i] = 0f; armed[i] = false; pressing[i] = false }
    }

    // times: 0 = Santos FC, 1 = Flamengo, 2 = Real Madrid, 3 = Barcelona
    val team = intArrayOf(0, 1)
    var selecting = 0          // quem esta escolhendo o time agora (0 = J1, 1 = J2 ou CPU)
    @Volatile var cursor = 0

    fun enterTeamSelect(ai: Boolean) {
        vsAI = ai
        score[0] = 0; score[1] = 0
        resetPositions()
        selecting = 0
        cursor = team[0]
        state = TEAMSEL
    }

    fun moveCursor(d: Int) {
        cursor = (cursor + d + TEAMS) % TEAMS
    }

    /** Confirma o time sob o cursor: o J1 escolhe e passa pro J2; o J2 escolhe e vai pros controles. */
    fun confirmTeam() {
        if (state != TEAMSEL) return
        if (selecting == 1 && cursor == team[0]) return
        team[selecting] = cursor
        if (selecting == 0) {
            selecting = 1
            cursor = if (team[1] != team[0]) team[1] else (team[0] + 1) % TEAMS
        } else {
            state = CONTROLS
        }
    }

    /** Volta um passo. Retorna true se deve sair pro menu. */
    fun backTeam(): Boolean {
        if (selecting == 1) {
            selecting = 0
            cursor = team[0]
            return false
        }
        return true
    }

    fun toControls() { state = CONTROLS }

    /** Entra na tela de controles antes da partida. */
    fun enterControls(ai: Boolean) {
        vsAI = ai
        score[0] = 0; score[1] = 0
        resetPositions()
        state = CONTROLS
    }

    private fun startMatch() {
        score[0] = 0; score[1] = 0
        timeLeft = matchSeconds.toFloat()
        resetPositions()
        lastScorer = -1
        state = KICKOFF
        stateTimer = 3f
    }

    fun update(dt0: Float) {
        val dt = min(dt0, 0.05f)
        time += dt
        if (pendingStart) { pendingStart = false; startMatch() }
        val st = state
        if (st == KICKOFF) {
            aiX = 0f; aiZ = 0f
            movePlayers(dt)
            moveTeammates(dt)
            stateTimer -= dt
            if (stateTimer <= 0f) state = PLAY
        } else if (st == PLAY) {
            if (vsAI) aiThink(dt) else { aiX = 0f; aiZ = 0f }
            handleKicks(dt)
            for (p in 0..1) {
                val passDown = passTouch[p]
                if (passDown && !passWasDown[p] && !(vsAI && p == 1)) passBall(p)
                passWasDown[p] = passDown
            }
            movePlayers(dt)
            moveTeammates(dt)
            updatePossession(dt)
            if (owner >= 0) {
                val o = owner
                val ex = bx
                val ez = bz
                ballWalls()
                if (owner >= 0 && hypot(bx - ex, bz - ez) > 0.3f) { owner = -1; pickCd[o] = 0.4f }
            } else {
                ballPhysics(dt / 2f)
                ballPhysics(dt / 2f)
            }
            // Quando a bola chega ao companheiro escolhido, ele vira o jogador controlado.
            if (pendingPassMate >= 0 && hypot(bx - pendingPassX, bz - pendingPassZ) < 1.25f && by < 1.2f) {
                val i = pendingPassMate
                val oldX = px[0]; val oldZ = pz[0]
                px[0] = mateX[i]; pz[0] = mateZ[i]
                vx[0] = mateVx[i]; vz[0] = mateVz[i]
                yaw[0] = mateYaw[i]; runPhase[0] = matePhase[i]
                mateX[i] = oldX; mateZ[i] = oldZ
                mateVx[i] = 0f; mateVz[i] = 0f
                owner = 0; protect = 0.45f; pickCd[0] = 0f
                bx = px[0] + sin(yaw[0] * PIF / 180f) * 0.72f
                bz = pz[0] + cos(yaw[0] * PIF / 180f) * 0.72f
                by = BR; bvx = vx[0]; bvz = vz[0]; bvy = 0f
                pendingPassMate = -1
            }
            timeLeft -= dt
            if (state == PLAY && timeLeft <= 0f) { timeLeft = 0f; state = END }
        } else if (st == GOAL) {
            for (p in 0..1) {
                val f = max(0f, 1f - 6f * dt)
                vx[p] *= f; vz[p] *= f
            }
            ballPhysics(dt / 2f)
            ballPhysics(dt / 2f)
            stateTimer -= dt
            if (stateTimer <= 0f) { resetPositions(); state = KICKOFF; stateTimer = 2f }
        }
        if (state != PLAY) {
            for (i in 0..1) { charge[i] = 0f; wasHeld[i] = false; armed[i] = false; pressing[i] = false; passWasDown[i] = false }
        }
        for (p in 0..1) if (kickAnim[p] > 0f) kickAnim[p] = max(0f, kickAnim[p] - dt)
    }

    private fun handleKicks(dt: Float) {
        for (p in 0..1) {
            if (vsAI && p == 1) continue
            val held = kickTouch[p] || kickBtn[p] || kickTrig[p]
            val oppOwns = owner >= 0 && owner != p
            pressing[p] = held && oppOwns
            if (held && !oppOwns) {
                armed[p] = true
                charge[p] = min(1f, charge[p] + dt / 0.9f)
            } else if (held) {
                armed[p] = false
                charge[p] = 0f
            } else {
                if (armed[p]) shoot(p, 0.3f + 0.7f * charge[p])
                armed[p] = false
                charge[p] = 0f
            }
        }
    }

    private fun movePlayers(dt: Float) {
        for (p in 0..1) {
            var jx: Float
            var jy: Float
            if (pressing[p] && owner >= 0 && owner != p) {
                // segurando o botao sem a bola: persegue quem esta com ela
                val ddx = px[owner] - px[p]
                val ddz = pz[owner] - pz[p]
                val dl = max(0.001f, hypot(ddx, ddz))
                jx = ddx / dl; jy = ddz / dl
            } else if (vsAI && p == 1) {
                jx = aiX; jy = aiZ
            } else if (padFor(p)) {
                val sx = stickX[p]
                val sy = stickY[p]
                if (hypot(sx, sy) > 0.01f) {
                    jx = sx; jy = sy
                } else {
                    jx = hatX[p] + keyDX[p]
                    jy = hatY[p] + keyDY[p]
                }
            } else {
                jx = joyX[p]; jy = joyY[p]
            }
            val mag = hypot(jx, jy)
            if (mag > 1f) { jx /= mag; jy /= mag }
            val speedMul = if (vsAI && p == 1) 0.88f else 1f
            val tx = jx * SPEED * speedMul
            val tz = jy * SPEED * speedMul
            val k = min(1f, 10f * dt)
            vx[p] += (tx - vx[p]) * k
            vz[p] += (tz - vz[p]) * k
            px[p] += vx[p] * dt
            pz[p] += vz[p] * dt
            px[p] = px[p].coerceIn(-HL - 0.8f, HL + 0.8f)
            pz[p] = pz[p].coerceIn(-HW - 0.8f, HW + 0.8f)
            val sp = hypot(vx[p], vz[p])
            if (sp > 0.6f) {
                val target = atan2(vx[p], vz[p]) * 180f / PIF
                var d = target - yaw[p]
                while (d > 180f) d -= 360f
                while (d < -180f) d += 360f
                yaw[p] += d * min(1f, 14f * dt)
                runPhase[p] += sp * dt * 2.0f
            }
        }
        val dx = px[1] - px[0]
        val dz = pz[1] - pz[0]
        val d = hypot(dx, dz)
        if (d < 0.8f && d > 0.0001f) {
            val push = (0.8f - d) / 2f
            val nx = dx / d
            val nz = dz / d
            px[0] -= nx * push; pz[0] -= nz * push
            px[1] += nx * push; pz[1] += nz * push
        }
    }

    /** IA dos 20 companheiros: acompanham o ataque, pressionam e procuram espaço. */
    private fun moveTeammates(dt: Float) {
        for (i in 0 until 20) {
            if (i == pendingPassMate) {
                mateVx[i] = 0f; mateVz[i] = 0f
                mateRun[i] = 0f
                continue
            }
            val side = i / 10
            val dir = if (side == 0) 1f else -1f
            val ownPossession = owner == side
            val enemyPossession = owner == 1 - side
            val ballNear = hypot(bx - mateX[i], bz - mateZ[i])
            val ballProgress = (bx / Game.HL).coerceIn(-1f, 1f) * dir
            // A linha inteira acompanha a jogada; a equipe ataca e recua em bloco.
            val teamShift = ballProgress * 3.2f
            var tx = mateBaseX[i] + dir * teamShift
            var tz = mateBaseZ[i]
            if (ownPossession) tx += dir * 2.0f
            if (enemyPossession) tx -= dir * 1.2f

            // Um companheiro próximo da bola pressiona ou oferece opção de passe.
            if ((owner < 0 && ballNear < 9f) || (enemyPossession && ballNear < 10f)) {
                val dx = bx - mateX[i]
                val dz = bz - mateZ[i]
                val len = max(0.001f, hypot(dx, dz))
                val chase = if (enemyPossession || owner < 0) 0.82f else 0.35f
                tx = mateX[i] + dx / len * min(4.8f, ballNear) * chase
                tz = mateZ[i] + dz / len * min(4.8f, ballNear) * chase
            } else if (ownPossession) {
                // Abre linhas de passe em profundidade e largura.
                tx += dir * (1.0f + (i % 3) * 0.65f)
                tz += sin(time * 1.1f + i * 1.35f) * 1.15f
            } else {
                tz += sin(time * 0.75f + i * 1.7f) * 0.7f
            }
            tx = tx.coerceIn(-HL + 1.2f, HL - 1.2f)
            tz = tz.coerceIn(-HW + 1.2f, HW - 1.2f)
            val dx = tx - mateX[i]
            val dz = tz - mateZ[i]
            val len = hypot(dx, dz)
            val speed = if (ballNear < 7f) 5.4f else 4.0f
            val desiredX = if (len > 0.12f) dx / len * speed else 0f
            val desiredZ = if (len > 0.12f) dz / len * speed else 0f
            val k = min(1f, 4.5f * dt)
            mateVx[i] += (desiredX - mateVx[i]) * k
            mateVz[i] += (desiredZ - mateVz[i]) * k
            mateX[i] = (mateX[i] + mateVx[i] * dt).coerceIn(-HL + 0.7f, HL - 0.7f)
            mateZ[i] = (mateZ[i] + mateVz[i] * dt).coerceIn(-HW + 0.7f, HW - 0.7f)
            val sp = hypot(mateVx[i], mateVz[i])
            mateRun[i] = min(1f, sp / SPEED)
            matePhase[i] += sp * dt * 2.5f
            if (sp > 0.25f) mateYaw[i] = atan2(mateVx[i], mateVz[i]) * 180f / PIF
        }
    }

    private fun aiThink(dt: Float) {
        val p = 1
        // J2 (CPU) ataca o gol da esquerda (x = -HL)
        var gx = -HL - bx
        var gz = 0f - bz
        val gl = max(0.001f, hypot(gx, gz))
        gx /= gl; gz /= gl
        val toBall = hypot(bx - px[p], bz - pz[p])
        aiCool -= dt
        pressing[p] = owner == 0
        if (owner == 0) {
            // jogador esta com a bola: CPU vai atras e rouba
            val mx = px[0] - px[p]
            val mz = pz[0] - pz[p]
            val ml = max(0.001f, hypot(mx, mz))
            aiX = mx / ml; aiZ = mz / ml
        } else if (toBall < 1.1f) {
            // com a bola: conduz pro gol e chuta quando chega perto
            aiX = gx; aiZ = gz
            val ahead = (bx - px[p]) * gx + (bz - pz[p]) * gz
            val dGoal = hypot(px[p] + HL, pz[p])
            if (ahead > 0f && dGoal < 8f && aiCool <= 0f) {
                val jitter = (Random.nextFloat() - 0.5f) * 0.3f
                yaw[p] = (atan2(gx, gz) + jitter) * 180f / PIF
                shoot(p, 0.55f + Random.nextFloat() * 0.35f)
                aiCool = 0.7f + Random.nextFloat() * 0.7f
            }
        } else {
            // vai pro ponto atras da bola (do lado oposto ao gol)
            var mx = (bx - gx * 0.8f) - px[p]
            var mz = (bz - gz * 0.8f) - pz[p]
            val ml = max(0.001f, hypot(mx, mz))
            mx /= ml; mz /= ml
            aiX = mx; aiZ = mz
        }
    }

    /** Bola no pe: quem chega perto da bola domina; quem segura o botao rouba. */
    private fun updatePossession(dt: Float) {
        for (p in 0..1) pickCd[p] = max(0f, pickCd[p] - dt)
        protect = max(0f, protect - dt)
        if (owner >= 0) {
            val d = 1 - owner
            val near = min(hypot(px[d] - bx, pz[d] - bz), hypot(px[d] - px[owner], pz[d] - pz[owner]))
            if (protect <= 0f && pressing[d] && near < 0.95f) {
                pickCd[owner] = 0.5f
                owner = d
                protect = 0.8f
            }
            val o = owner
            val a = yaw[o] * PIF / 180f
            val dist = 0.72f + 0.10f * sin(runPhase[o])
            bx = px[o] + sin(a) * dist
            bz = pz[o] + cos(a) * dist
            by = BR
            bvx = vx[o]; bvz = vz[o]; bvy = 0f
        } else {
            var best = -1
            var bestD = 0.75f
            for (p in 0..1) {
                if (pickCd[p] > 0f) continue
                val dd = hypot(bx - px[p], bz - pz[p])
                val rel = hypot(bvx - vx[p], bvz - vz[p])
                if (dd < bestD && by < 0.8f && rel < 11f) { best = p; bestD = dd }
            }
            if (best >= 0) { owner = best; protect = 0.5f }
        }
    }

    private fun passBall(p: Int) {
        if (p != 0 || (owner != p && hypot(bx - px[p], bz - pz[p]) > 1.7f)) return
        // Escolhe o companheiro mais avançado que ainda esteja em posição alcançável.
        var best = -1
        var bestScore = Float.NEGATIVE_INFINITY
        for (slot in 0 until 10) {
            val i = slot // os índices 0..9 são os dez companheiros do J1
            val forward = mateX[i] - px[p]
            val lateral = abs(mateZ[i] - pz[p])
            if (forward > 0.5f) {
                val score = forward - lateral * 0.38f - hypot(mateX[i] - px[p], mateZ[i] - pz[p]) * 0.08f
                if (score > bestScore) { bestScore = score; best = i }
            }
        }
        if (best < 0) {
            best = (0 until 10).minByOrNull { hypot(mateX[it] - px[p], mateZ[it] - pz[p]) } ?: return
        }
        val tx = mateX[best]
        val tz = mateZ[best]
        val dx = tx - bx
        val dz = tz - bz
        val len = max(0.01f, hypot(dx, dz))
        val speed = (len * 1.65f).coerceIn(8.5f, 15.5f)
        bvx = dx / len * speed
        bvz = dz / len * speed
        bvy = 0.45f
        owner = -1
        pendingPassMate = best
        pendingPassX = tx
        pendingPassZ = tz
        kickAnim[p] = 0.22f
        pickCd[p] = 0.35f
    }

    private fun shoot(p: Int, power: Float) {
        kickAnim[p] = 0.3f
        val d = hypot(bx - px[p], bz - pz[p])
        if (owner == p || (owner < 0 && d < 1.5f && by < 1.3f)) {
            val a = yaw[p] * PIF / 180f
            val speed = 6f + 12f * power
            bvx = sin(a) * speed + vx[p] * 0.3f
            bvz = cos(a) * speed + vz[p] * 0.3f
            bvy = 1.5f + 3f * power
            owner = -1
            pickCd[p] = 0.45f
        }
    }

    private fun ballPhysics(dt: Float) {
        bvy -= 22f * dt
        bx += bvx * dt
        by += bvy * dt
        bz += bvz * dt
        if (by < BR) {
            by = BR
            bvy = if (bvy < -2f) -bvy * 0.55f else 0f
        }
        val f = if (by <= BR + 0.02f) exp(-1.1f * dt) else exp(-0.1f * dt)
        bvx *= f; bvz *= f

        // jogadores empurram a bola
        for (p in 0..1) {
            val dx = bx - px[p]
            val dz = bz - pz[p]
            val d = hypot(dx, dz)
            val r = 0.55f
            if (d < r && by < 1.1f) {
                val nx = if (d > 0.0001f) dx / d else 1f
                val nz = if (d > 0.0001f) dz / d else 0f
                bx = px[p] + nx * r
                bz = pz[p] + nz * r
                val rel = (bvx - vx[p]) * nx + (bvz - vz[p]) * nz
                if (rel < 0f) {
                    bvx -= 1.4f * rel * nx
                    bvz -= 1.4f * rel * nz
                }
            }
        }

        ballWalls()
    }

    private fun ballWalls() {
        // paredes laterais (dentro do gol a rede segura a bola)
        val inGoalX = abs(bx) > HL + 0.1f
        val zLim = if (inGoalX) GOALW else HW
        if (bz > zLim - BR) { bz = zLim - BR; bvz = -abs(bvz) * 0.6f }
        if (bz < -zLim + BR) { bz = -zLim + BR; bvz = abs(bvz) * 0.6f }

        // linha de fundo: so entra pela boca do gol
        val open = abs(bz) < GOALW - BR && by < GOALH - BR
        val ax = abs(bx)
        if (ax > HL - BR && ax < HL + 1f && !open) {
            bx = sign(bx) * (HL - BR)
            bvx = -bvx * 0.6f
        }
        if (abs(bx) > HL + GOALD - BR) {
            bx = sign(bx) * (HL + GOALD - BR)
            bvx = -bvx * 0.4f
        }

        if (state == PLAY && abs(bx) > HL + 0.1f) {
            val s = if (bx > 0f) 0 else 1
            score[s]++
            lastScorer = s
            state = GOAL
            owner = -1
            stateTimer = 3f
        }
    }
}
