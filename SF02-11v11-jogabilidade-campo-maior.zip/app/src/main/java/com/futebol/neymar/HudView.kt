package com.futebol.neymar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

class HudView(ctx: Context, private val game: Game, private val onMenu: () -> Unit) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val joyId = intArrayOf(-1, -1)
    private val ox = FloatArray(2)
    private val oy = FloatArray(2)
    private val cx = FloatArray(2)
    private val cy = FloatArray(2)
    private val kickId = intArrayOf(-1, -1)
    private val passId = intArrayOf(-1, -1)
    private val rematchBtn = RectF()
    private val menuBtn = RectF()
    private val startBtn = RectF()
    private val backBtn = RectF()
    private val rect = RectF()
    private val c1 = 0xFFE53935.toInt()
    private val c2 = 0xFF1E88E5.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val crest = arrayOfNulls<Bitmap>(8)
    private val teamNames = arrayOf("Santos FC", "Flamengo", "Real Madrid", "FC Barcelona", "Paris Saint-Germain", "Arsenal", "Bayern de Munique", "Borussia Dortmund")
    private val tileRects = Array(8) { RectF() }
    private val contBtn = RectF()

    init {
        p.isFilterBitmap = true
        try {
            crest[0] = BitmapFactory.decodeStream(ctx.assets.open("santos.png"))
            crest[1] = BitmapFactory.decodeStream(ctx.assets.open("flamengo.png"))
            crest[2] = BitmapFactory.decodeStream(ctx.assets.open("realmadrid.png"))
            crest[3] = BitmapFactory.decodeStream(ctx.assets.open("barcelona.png"))
            crest[4] = BitmapFactory.decodeStream(ctx.assets.open("psg.png"))
            crest[5] = BitmapFactory.decodeStream(ctx.assets.open("arsenal.png"))
            crest[6] = BitmapFactory.decodeStream(ctx.assets.open("bayern.png"))
            crest[7] = BitmapFactory.decodeStream(ctx.assets.open("bvb.png"))
        } catch (e: Exception) {
        }
    }

    private fun drawCrest(c: Canvas, idx: Int, cxp: Float, cyp: Float, size: Float) {
        val b = crest[idx] ?: return
        val sc = size / max(b.width, b.height).toFloat()
        val bw = b.width * sc
        val bh = b.height * sc
        rect.set(cxp - bw / 2f, cyp - bh / 2f, cxp + bw / 2f, cyp + bh / 2f)
        p.style = Paint.Style.FILL
        p.color = white
        c.drawBitmap(b, null, rect, p)
    }

    fun reset() {
        for (i in 0..1) {
            joyId[i] = -1; kickId[i] = -1
            game.joyX[i] = 0f; game.joyY[i] = 0f
            game.kickTouch[i] = false
            game.passTouch[i] = false
        }
    }

    private fun joyR() = height * 0.17f
    private fun kx(i: Int) = if (game.vsAI) width * 0.89f else if (i == 0) width * 0.42f else width * 0.58f
    private fun ky() = height * 0.82f
    private fun kr() = height * 0.092f
    private fun passX(i: Int) = if (game.vsAI) width * 0.70f else if (i == 0) width * 0.30f else width * 0.70f
    private fun passY() = height * 0.82f
    private fun passR() = height * 0.092f
    private fun hx(i: Int) = if (i == 0) width * 0.13f else width * 0.87f
    private fun hy() = height * 0.72f
    private fun teamColor(i: Int) = if (i == 0) c1 else c2
    private fun nm(i: Int) = if (i == 1 && game.vsAI) "CPU" else "J" + (i + 1)
    private fun usesTouch(i: Int) = !(game.vsAI && i == 1) && !game.padFor(i)
    private fun alpha(col: Int, a: Int) = (col and 0x00FFFFFF) or (a shl 24)

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = size
        p.color = color
        p.setShadowLayer(size * 0.06f, 0f, size * 0.04f, 0xAA000000.toInt())
        c.drawText(s, x, y, p)
        p.clearShadowLayer()
    }

    override fun onDraw(c: Canvas) {
        val st = game.state
        if (st == Game.MENU) return
        val w = width.toFloat()
        val h = height.toFloat()

        if (st == Game.CONTROLS) {
            drawControlsScreen(c, w, h)
            return
        }
        if (st == Game.TEAMSEL) {
            drawTeamScreen(c, w, h)
            return
        }

        // placar
        rect.set(w * 0.30f, h * 0.02f, w * 0.70f, h * 0.20f)
        p.style = Paint.Style.FILL
        p.color = 0x99000000.toInt()
        c.drawRoundRect(rect, h * 0.04f, h * 0.04f, p)
        drawCrest(c, game.team[0], w * 0.325f, h * 0.11f, h * 0.13f)
        drawCrest(c, game.team[1], w * 0.675f, h * 0.11f, h * 0.13f)
        txt(c, nm(0), w * 0.405f, h * 0.115f, h * 0.05f, c1)
        txt(c, nm(1), w * 0.595f, h * 0.115f, h * 0.05f, c2)
        txt(c, "${game.score[0]} - ${game.score[1]}", w * 0.5f, h * 0.125f, h * 0.095f, white)
        val secs = ceil(game.timeLeft).toInt()
        txt(c, String.format("%d:%02d", secs / 60, secs % 60), w * 0.5f, h * 0.185f, h * 0.05f, 0xFFFFD500.toInt())

        if (st == Game.PLAY || st == Game.KICKOFF) drawCursors(c, w, h)
        if (st != Game.END) drawTouchControls(c)

        if (st == Game.KICKOFF) {
            val n = ceil(game.stateTimer).toInt().coerceIn(1, 3)
            txt(c, n.toString(), w * 0.5f, h * 0.55f, h * 0.28f, white)
        } else if (st == Game.GOAL) {
            txt(c, "GOOOL!", w * 0.5f, h * 0.50f, h * 0.22f, 0xFFFFD500.toInt())
            if (game.lastScorer >= 0) {
                txt(c, nm(game.lastScorer) + " marcou!", w * 0.5f, h * 0.62f, h * 0.07f, teamColor(game.lastScorer))
            }
        } else if (st == Game.END) {
            p.style = Paint.Style.FILL
            p.color = 0xBB000000.toInt()
            c.drawRect(0f, 0f, w, h, p)
            txt(c, "FIM DE JOGO", w * 0.5f, h * 0.28f, h * 0.12f, white)
            txt(c, "${game.score[0]} - ${game.score[1]}", w * 0.5f, h * 0.50f, h * 0.16f, 0xFFFFD500.toInt())
            val s0 = game.score[0]
            val s1 = game.score[1]
            if (s0 == s1) txt(c, "EMPATE!", w * 0.5f, h * 0.61f, h * 0.07f, white)
            else {
                val win = if (s0 > s1) 0 else 1
                txt(c, nm(win) + " GANHOU!", w * 0.5f, h * 0.61f, h * 0.07f, teamColor(win))
            }
            val bw = w * 0.22f
            val bh = h * 0.14f
            val gap = w * 0.03f
            rematchBtn.set(w * 0.5f - bw - gap / 2f, h * 0.68f, w * 0.5f - gap / 2f, h * 0.68f + bh)
            menuBtn.set(w * 0.5f + gap / 2f, h * 0.68f, w * 0.5f + gap / 2f + bw, h * 0.68f + bh)
            p.style = Paint.Style.FILL
            p.color = 0xFF2E9E3F.toInt()
            c.drawRoundRect(rematchBtn, bh / 2f, bh / 2f, p)
            p.color = 0xFF555555.toInt()
            c.drawRoundRect(menuBtn, bh / 2f, bh / 2f, p)
            txt(c, "REVANCHE", rematchBtn.centerX(), rematchBtn.centerY() + h * 0.02f, h * 0.06f, white)
            txt(c, "MENU", menuBtn.centerX(), menuBtn.centerY() + h * 0.02f, h * 0.06f, white)
        }
    }

    // cursor estilo PES: triangulo sobre o jogador, seta de direcao e barra de forca
    private fun drawCursors(c: Canvas, w: Float, h: Float) {
        for (i in 0..1) {
            if (game.vsAI && i == 1) continue
            val col = teamColor(i)
            val hx = game.headX[i] * w
            val hy = game.headY[i] * h
            val s = h * 0.024f
            val bob = sin(game.time * 6f) * s * 0.25f
            path.reset()
            path.moveTo(hx - s, hy - s + bob)
            path.lineTo(hx + s, hy - s + bob)
            path.lineTo(hx, hy + s * 0.7f + bob)
            path.close()
            p.style = Paint.Style.FILL
            p.color = col
            c.drawPath(path, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.2f
            p.color = white
            c.drawPath(path, p)

            // seta no chao na direcao do movimento
            val sp = hypot(game.vx[i], game.vz[i])
            if (sp > 0.8f) {
                val fx = game.footX[i] * w
                val fy = game.footY[i] * h
                val axp = game.aheadX[i] * w
                val ayp = game.aheadY[i] * h
                var dx = axp - fx
                var dy = ayp - fy
                val len = hypot(dx, dy)
                if (len > 1f) {
                    dx /= len; dy /= len
                    val a = h * 0.035f
                    val nx = -dy
                    val ny = dx
                    path.reset()
                    path.moveTo(axp + dx * a, ayp + dy * a)
                    path.lineTo(axp - dx * a * 0.5f + nx * a * 0.9f, ayp - dy * a * 0.5f + ny * a * 0.9f)
                    path.lineTo(axp - dx * a * 0.1f, ayp - dy * a * 0.1f)
                    path.lineTo(axp - dx * a * 0.5f - nx * a * 0.9f, ayp - dy * a * 0.5f - ny * a * 0.9f)
                    path.close()
                    p.style = Paint.Style.FILL
                    p.color = alpha(col, 0xDD)
                    c.drawPath(path, p)
                }
            }

            // barra de forca do chute (verde -> vermelho)
            val ch = game.charge[i]
            if (ch > 0.04f) {
                val bw = h * 0.22f
                val bh = h * 0.024f
                val bl = game.footX[i] * w - bw / 2f
                val bt = game.footY[i] * h + h * 0.045f
                rect.set(bl - 3f, bt - 3f, bl + bw + 3f, bt + bh + 3f)
                p.style = Paint.Style.FILL
                p.color = 0xCC000000.toInt()
                c.drawRoundRect(rect, bh, bh, p)
                p.shader = LinearGradient(
                    bl, 0f, bl + bw, 0f,
                    intArrayOf(0xFF2ECC40.toInt(), 0xFFFFDC00.toInt(), 0xFFFF4136.toInt()),
                    null, Shader.TileMode.CLAMP
                )
                c.save()
                c.clipRect(bl, bt, bl + bw * ch, bt + bh)
                rect.set(bl, bt, bl + bw, bt + bh)
                c.drawRoundRect(rect, bh / 2f, bh / 2f, p)
                c.restore()
                p.shader = null
            }
        }
    }

    private fun drawTouchControls(c: Canvas) {
        val r = joyR()
        for (i in 0..1) {
            if (!usesTouch(i)) continue
            val col = teamColor(i)
            p.style = Paint.Style.STROKE
            p.strokeWidth = height * 0.008f
            if (joyId[i] == -1) {
                p.color = alpha(col, 0x55)
                c.drawCircle(hx(i), hy(), r, p)
                txt(c, nm(i), hx(i), hy() + height * 0.025f, height * 0.07f, alpha(col, 0x66))
            } else {
                p.color = alpha(col, 0x88)
                c.drawCircle(ox[i], oy[i], r, p)
                p.style = Paint.Style.FILL
                p.color = alpha(col, 0xAA)
                c.drawCircle(cx[i], cy[i], r * 0.4f, p)
            }
            p.style = Paint.Style.FILL
            val pressed = kickId[i] != -1
            p.color = alpha(col, if (pressed) 0xDD else 0x88)
            c.drawCircle(kx(i), ky(), kr(), p)
            txt(c, "CHUTAR", kx(i), ky() + kr() * 0.14f, kr() * 0.34f, white)
            p.color = alpha(col, if (passId[i] != -1) 0xDD else 0x88)
            c.drawCircle(passX(i), passY(), passR(), p)
            txt(c, "PASSE", passX(i), passY() + passR() * 0.14f, passR() * 0.38f, white)
        }
    }

    private fun shorten(s: String) = if (s.length > 24) s.substring(0, 24) + ".." else s

    private fun drawPadIcon(c: Canvas, x: Float, y: Float, size: Float, on: Boolean, col: Int) {
        val bw = size
        val bh = size * 0.55f
        rect.set(x - bw / 2f, y - bh / 2f, x + bw / 2f, y + bh / 2f)
        p.style = Paint.Style.FILL
        p.color = if (on) col else 0xFF4A5268.toInt()
        c.drawRoundRect(rect, bh * 0.45f, bh * 0.45f, p)
        p.color = 0xFF18213B.toInt()
        val dx = x - bw * 0.24f
        val dy = y - bh * 0.05f
        c.drawRect(dx - bw * 0.09f, dy - bh * 0.045f, dx + bw * 0.09f, dy + bh * 0.045f, p)
        c.drawRect(dx - bh * 0.045f, dy - bw * 0.09f, dx + bh * 0.045f, dy + bw * 0.09f, p)
        c.drawCircle(x + bw * 0.22f, y - bh * 0.12f, bh * 0.08f, p)
        c.drawCircle(x + bw * 0.31f, y + bh * 0.08f, bh * 0.08f, p)
    }

    private fun txtL(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = size
        p.color = color
        p.setShadowLayer(size * 0.06f, 0f, size * 0.04f, 0xAA000000.toInt())
        c.drawText(s, x, y, p)
        p.clearShadowLayer()
    }

    private fun drawTeamScreen(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF061450.toInt(), 0xFF0A2A9A.toInt(), 0xFF040C33.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        val cur = game.cursor
        val sel = game.selecting
        val selCol = teamColor(sel)
        drawCrest(c, cur, w * 0.07f, h * 0.17f, h * 0.17f)
        txtL(c, teamNames[cur], w * 0.14f, h * 0.20f, h * 0.10f, 0xFFFFE900.toInt())
        val label = if (sel == 1 && game.vsAI) "ESCOLHA O TIME DA CPU" else nm(sel) + ", ESCOLHA SEU TIME"
        txtL(c, label, w * 0.14f, h * 0.30f, h * 0.045f, selCol)

        if (sel == 1) {
            drawCrest(c, game.team[0], w * 0.92f, h * 0.15f, h * 0.13f)
            txt(c, "J1", w * 0.92f, h * 0.265f, h * 0.045f, c1)
        }

        val ts = h * 0.20f
        val gap = h * 0.03f
        for (t in 0 until Game.TEAMS) {
            val x = w * 0.06f + (t % 4) * (ts + gap)
            val y = h * 0.37f + (t / 4) * (ts + gap)
            tileRects[t].set(x, y, x + ts, y + ts)
            val hl = t == cur
            val taken = sel == 1 && t == game.team[0]
            p.style = Paint.Style.FILL
            p.color = if (hl) white else 0xFF2A2A2E.toInt()
            c.drawRoundRect(tileRects[t], h * 0.03f, h * 0.03f, p)
            if (hl) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = h * 0.008f
                p.color = 0xFF9FB8FF.toInt()
                c.drawRoundRect(tileRects[t], h * 0.03f, h * 0.03f, p)
            }
            drawCrest(c, t, x + ts / 2f, y + ts / 2f, ts * 0.72f)
            if (taken) {
                p.style = Paint.Style.FILL
                p.color = 0xAA000000.toInt()
                c.drawRoundRect(tileRects[t], h * 0.03f, h * 0.03f, p)
                txt(c, "J1", x + ts / 2f, y + ts * 0.62f, h * 0.05f, c1)
            }
        }

        txt(c, "Toque num time e depois em ESCOLHER. Controle: esquerda/direita move, A escolhe, B volta",
            w * 0.5f, h * 0.845f, h * 0.03f, 0xFFB0B8CC.toInt())
        val bw = w * 0.22f
        val bh = h * 0.095f
        backBtn.set(w * 0.05f, h * 0.885f, w * 0.05f + bw, h * 0.885f + bh)
        contBtn.set(w * 0.05f + bw + w * 0.03f, h * 0.885f, w * 0.05f + 2f * bw + w * 0.03f, h * 0.885f + bh)
        p.style = Paint.Style.FILL
        p.color = 0xFF1E3FD8.toInt()
        c.drawRoundRect(backBtn, bh / 2f, bh / 2f, p)
        p.color = 0xFF2E9E3F.toInt()
        c.drawRoundRect(contBtn, bh / 2f, bh / 2f, p)
        txt(c, "VOLTAR", backBtn.centerX(), backBtn.centerY() + h * 0.018f, h * 0.05f, white)
        txt(c, "ESCOLHER", contBtn.centerX(), contBtn.centerY() + h * 0.018f, h * 0.05f, white)
    }

    private fun drawControlsScreen(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = 0xCC000000.toInt()
        c.drawRect(0f, 0f, w, h, p)
        txt(c, "CONTROLES", w * 0.5f, h * 0.13f, h * 0.085f, white)
        for (i in 0..1) {
            val l = if (i == 0) w * 0.07f else w * 0.52f
            val r = l + w * 0.41f
            val mid = (l + r) / 2f
            val col = teamColor(i)
            rect.set(l, h * 0.19f, r, h * 0.68f)
            p.style = Paint.Style.FILL
            p.color = 0xFF18213B.toInt()
            c.drawRoundRect(rect, h * 0.03f, h * 0.03f, p)
            rect.set(l, h * 0.19f, r, h * 0.29f)
            p.color = col
            c.drawRoundRect(rect, h * 0.03f, h * 0.03f, p)
            txt(c, nm(i) + (if (i == 0) "  VERMELHO" else "  AZUL"), mid, h * 0.265f, h * 0.055f, white)

            val cpu = game.vsAI && i == 1
            val pad = game.padFor(i)
            var status = ""
            var sub = ""
            if (cpu) {
                txt(c, "IA", mid, h * 0.5f, h * 0.16f, 0xFF8FA0B8.toInt())
                status = "CPU (IA)"; sub = "controlado pelo celular"
            } else {
                drawPadIcon(c, mid, h * 0.43f, h * 0.30f, pad, col)
                if (pad) { status = shorten(game.padName(i)); sub = "controle conectado" }
                else { status = "Sem controle"; sub = "joga pelo toque na tela" }
            }
            txt(c, status, mid, h * 0.565f, h * 0.05f, white)
            txt(c, sub, mid, h * 0.64f, h * 0.035f, 0xFFB0B8CC.toInt())
        }
        txt(c, "Conecte controles Xbox ou PS5: o 1o vira J1 (vermelho) e o 2o vira J2 (azul)", w * 0.5f, h * 0.75f, h * 0.032f, 0xFFB0B8CC.toInt())

        val bw = w * 0.24f
        val bh = h * 0.13f
        startBtn.set(w * 0.52f, h * 0.80f, w * 0.52f + bw, h * 0.80f + bh)
        backBtn.set(w * 0.48f - bw, h * 0.80f, w * 0.48f, h * 0.80f + bh)
        p.style = Paint.Style.FILL
        p.color = 0xFF2E9E3F.toInt()
        c.drawRoundRect(startBtn, bh / 2f, bh / 2f, p)
        p.color = 0xFF555555.toInt()
        c.drawRoundRect(backBtn, bh / 2f, bh / 2f, p)
        txt(c, "COMECAR", startBtn.centerX(), startBtn.centerY() + h * 0.02f, h * 0.055f, white)
        txt(c, "VOLTAR", backBtn.centerX(), backBtn.centerY() + h * 0.02f, h * 0.055f, white)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val st = game.state
        if (st == Game.END) {
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                if (rematchBtn.contains(e.x, e.y)) game.pendingStart = true
                else if (menuBtn.contains(e.x, e.y)) onMenu()
            }
            return true
        }
        if (st == Game.CONTROLS) {
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                if (startBtn.contains(e.x, e.y)) game.pendingStart = true
                else if (backBtn.contains(e.x, e.y)) game.state = Game.TEAMSEL
            }
            return true
        }
        if (st == Game.TEAMSEL) {
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                var hit = -1
                for (t in 0 until Game.TEAMS) if (tileRects[t].contains(e.x, e.y)) hit = t
                if (hit >= 0) {
                    if (game.cursor == hit) game.confirmTeam() else game.cursor = hit
                } else if (contBtn.contains(e.x, e.y)) game.confirmTeam()
                else if (backBtn.contains(e.x, e.y)) { if (game.backTeam()) onMenu() }
            }
            return true
        }
        if (st == Game.MENU) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> reset()
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        for (i in 0..1) {
            if (!usesTouch(i)) continue
            if (hypot(x - passX(i), y - passY()) < passR() * 1.35f) {
                passId[i] = id
                game.passTouch[i] = true
                return
            }
            if (hypot(x - kx(i), y - ky()) < kr() * 1.3f) {
                kickId[i] = id
                game.kickTouch[i] = true
                return
            }
        }
        val i = if (x < width * 0.5f) 0 else 1
        if (!usesTouch(i)) return
        if (joyId[i] == -1) {
            joyId[i] = id
            ox[i] = x; oy[i] = y; cx[i] = x; cy[i] = y
            game.joyX[i] = 0f; game.joyY[i] = 0f
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        for (i in 0..1) {
            if (joyId[i] == id) {
                val r = joyR()
                var dx = x - ox[i]
                var dy = y - oy[i]
                val len = hypot(dx, dy)
                if (len > r) { dx = dx / len * r; dy = dy / len * r }
                cx[i] = ox[i] + dx
                cy[i] = oy[i] + dy
                if (len < r * 0.15f) { game.joyX[i] = 0f; game.joyY[i] = 0f }
                else { game.joyX[i] = dx / r; game.joyY[i] = dy / r }
            }
        }
    }

    private fun up(id: Int) {
        for (i in 0..1) {
            if (joyId[i] == id) { joyId[i] = -1; game.joyX[i] = 0f; game.joyY[i] = 0f }
            if (kickId[i] == id) { kickId[i] = -1; game.kickTouch[i] = false }
            if (passId[i] == id) { passId[i] = -1; game.passTouch[i] = false }
        }
    }
}
