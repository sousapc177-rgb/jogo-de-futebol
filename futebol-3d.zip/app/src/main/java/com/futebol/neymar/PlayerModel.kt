package com.futebol.neymar

import android.content.Context
import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Jogador 3D (Professional Soccer Standing, CC0 - Innerscene Corp) convertido para player.bin.
 * Formato por vertice: pos(3) normal(3) uv(2) pesos(4: perna E, perna D, braco E, braco D)
 * Os pesos sao usados no vertex shader para animar corrida e chute.
 */
class PlayerModel(ctx: Context, private val loadTex: (String) -> Int) {

    companion object {
        const val SKIN = 0
        const val SHOES = 1
        const val HAIR = 2
        const val EYE = 3
        const val BROW = 4
        const val SHIRT = 6
        const val SHORTS = 7
        const val SOCKS = 8
        private const val STRIDE = 12 * 4
    }

    private class Sub(val kind: Int, val vbo: Int, val ibo: Int, val count: Int)

    private val subs = ArrayList<Sub>()
    private val tex = IntArray(5)

    init {
        val bytes = ctx.assets.open("player.bin").use { it.readBytes() }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val n = bb.getInt(4)
        var off = 8 + 16 * n
        for (i in 0 until n) {
            val h = 8 + 16 * i
            val kind = bb.getInt(h)
            val nV = bb.getInt(h + 4)
            val nI = bb.getInt(h + 8)

            val vb = ByteBuffer.allocateDirect(nV * STRIDE).order(ByteOrder.nativeOrder())
            bb.limit(off + nV * STRIDE); bb.position(off)
            vb.put(bb); vb.position(0)
            off += nV * STRIDE

            val ib = ByteBuffer.allocateDirect(nI * 2).order(ByteOrder.nativeOrder())
            bb.limit(off + nI * 2); bb.position(off)
            ib.put(bb); ib.position(0)
            off += (nI * 2 + 3) / 4 * 4
            bb.limit(bb.capacity())

            val ids = IntArray(2)
            GLES20.glGenBuffers(2, ids, 0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, nV * STRIDE, vb, GLES20.GL_STATIC_DRAW)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
            GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, nI * 2, ib, GLES20.GL_STATIC_DRAW)
            subs.add(Sub(kind, ids[0], ids[1], nI))
        }
        tex[SKIN] = loadTex("pl_skin.jpg")
        tex[SHOES] = loadTex("pl_shoes.jpg")
        tex[HAIR] = loadTex("pl_hair.png")
        tex[EYE] = loadTex("pl_eye.png")
        tex[BROW] = loadTex("pl_brow.png")
    }

    fun draw(aPos: Int, aNorm: Int, aUV: Int, aW: Int, uKind: Int) {
        for (s in subs) {
            GLES20.glUniform1f(uKind, s.kind.toFloat())
            if (s.kind <= BROW) GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[s.kind])
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, s.vbo)
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, STRIDE, 0)
            GLES20.glEnableVertexAttribArray(aNorm)
            GLES20.glVertexAttribPointer(aNorm, 3, GLES20.GL_FLOAT, false, STRIDE, 12)
            GLES20.glEnableVertexAttribArray(aUV)
            GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, STRIDE, 24)
            GLES20.glEnableVertexAttribArray(aW)
            GLES20.glVertexAttribPointer(aW, 4, GLES20.GL_FLOAT, false, STRIDE, 32)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, s.ibo)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, s.count, GLES20.GL_UNSIGNED_SHORT, 0)
        }
        GLES20.glDisableVertexAttribArray(aW)
    }
}

/** Uniforme do time: cores e estilo da camisa (0 liso, 1 listras horizontais, 2 verticais, 3 faixa central, 4 mangas) */
class Kit(val shirt: FloatArray, val shirt2: FloatArray, val shorts: FloatArray, val socks: FloatArray, val style: Int)

object Kits {
    private fun c(r: Float, g: Float, b: Float) = floatArrayOf(r, g, b)
    private val white = c(0.93f, 0.93f, 0.93f)
    private val black = c(0.06f, 0.06f, 0.07f)
    private val red = c(0.85f, 0.07f, 0.11f)

    // 0 Santos, 1 Flamengo, 2 Real Madrid, 3 Barcelona, 4 PSG, 5 Arsenal, 6 Bayern, 7 Dortmund
    private val home = arrayOf(
        Kit(white, white, white, white, 0),
        Kit(red, black, black, black, 1),
        Kit(white, white, white, white, 0),
        Kit(c(0.05f, 0.22f, 0.70f), c(0.66f, 0.05f, 0.25f), c(0.04f, 0.10f, 0.42f), c(0.04f, 0.10f, 0.42f), 2),
        Kit(c(0.03f, 0.08f, 0.30f), red, c(0.03f, 0.08f, 0.30f), c(0.03f, 0.08f, 0.30f), 3),
        Kit(red, white, white, red, 4),
        Kit(c(0.80f, 0.05f, 0.12f), white, white, white, 0),
        Kit(c(1.0f, 0.86f, 0.0f), black, black, c(1.0f, 0.86f, 0.0f), 0)
    )
    private val santosAlt = Kit(black, black, black, black, 0)
    private val realAlt = Kit(c(0.30f, 0.12f, 0.52f), white, c(0.16f, 0.07f, 0.32f), c(0.30f, 0.12f, 0.52f), 0)

    fun get(team: Int, alt: Boolean): Kit =
        if (alt && team == 0) santosAlt else if (alt && team == 2) realAlt else home[team]
}
