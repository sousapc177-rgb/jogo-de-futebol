# Futebol 3D
Futebol 1x1 para 2 jogadores no mesmo celular (Kotlin + OpenGL ES 2.0).

Modelo 3D: "Soccer player - standing" (Professional Soccer Standing) por Innerscene Corp, CC0 (dominio publico).
O modelo foi convertido para `app/src/main/assets/player.bin` (malha + pesos de animacao) e texturas `pl_*`.
As cores das camisas dos times sao feitas no shader (ver `Kits` em `PlayerModel.kt`).

Build: GitHub Actions (`.github/workflows/build.yml`) gera o APK debug como artefato.
