# SF 02

## Navegacao do menu (atualizacao)
- Controle: direcional para esquerda/direita ou cima/baixo para escolher um dos tres modos; A ou START para confirmar.
- Teclado: setas ou WASD para escolher; Enter ou Espaco para confirmar.

## Importante
Esta atualizacao corrige a navegacao do menu principal por teclado e controle. A partida ainda usa a estrutura antiga de dois jogadores (um por lado). O modo real 11 contra 11, com troca automatica para o companheiro que recebe o passe, ainda precisa de uma reformulacao do motor de jogo e nao esta incluido nesta versao.
