package com.futebol.neymar

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.View
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Malha com VBO: posicao(3) + normal(3) + extra(2 = uv, 3 = cor) */
class Mesh(data: FloatArray, private val extra: Int, indices: ShortArray?) {
    private val stride = (6 + extra) * 4
    private val vbo = IntArray(1)
    private val ibo = IntArray(1)
    private val indexed = indices != null
    val count: Int

    init {
        GLES20.glGenBuffers(1, vbo, 0)
        val fb = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(data)
        fb.position(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, fb, GLES20.GL_STATIC_DRAW)
        if (indices != null) {
            GLES20.glGenBuffers(1, ibo, 0)
            val sb = ByteBuffer.allocateDirect(indices.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
            sb.put(indices)
            sb.position(0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo[0])
            GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, indices.size * 2, sb, GLES20.GL_STATIC_DRAW)
            count = indices.size
        } else {
            count = data.size / (6 + extra)
        }
    }

    fun draw(pLoc: Int, nLoc: Int, eLoc: Int) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo[0])
        GLES20.glEnableVertexAttribArray(pLoc)
        GLES20.glVertexAttribPointer(pLoc, 3, GLES20.GL_FLOAT, false, stride, 0)
        GLES20.glEnableVertexAttribArray(nLoc)
        GLES20.glVertexAttribPointer(nLoc, 3, GLES20.GL_FLOAT, false, stride, 12)
        GLES20.glEnableVertexAttribArray(eLoc)
        GLES20.glVertexAttribPointer(eLoc, extra, GLES20.GL_FLOAT, false, stride, 24)
        if (indexed) {
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo[0])
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, count, GLES20.GL_UNSIGNED_SHORT, 0)
        } else {
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
        }
    }
}

/** Construtor de malhas simples (cores por vertice) */
class MB {
    var a = FloatArray(8192)
    var n = 0

    fun v(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float, c: FloatArray) {
        if (n + 9 > a.size) a = a.copyOf(a.size * 2)
        a[n++] = x; a[n++] = y; a[n++] = z
        a[n++] = nx; a[n++] = ny; a[n++] = nz
        a[n++] = c[0]; a[n++] = c[1]; a[n++] = c[2]
    }

    fun quad(
        x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float, x3: Float, y3: Float, z3: Float,
        nx: Float, ny: Float, nz: Float, c: FloatArray
    ) {
        v(x0, y0, z0, nx, ny, nz, c); v(x1, y1, z1, nx, ny, nz, c); v(x2, y2, z2, nx, ny, nz, c)
        v(x0, y0, z0, nx, ny, nz, c); v(x2, y2, z2, nx, ny, nz, c); v(x3, y3, z3, nx, ny, nz, c)
    }

    fun quadY(x0: Float, z0: Float, x1: Float, z1: Float, y: Float, c: FloatArray) {
        quad(x0, y, z0, x1, y, z0, x1, y, z1, x0, y, z1, 0f, 1f, 0f, c)
    }

    fun line(x1: Float, z1: Float, x2: Float, z2: Float, w: Float, c: FloatArray) {
        val dx = x2 - x1
        val dz = z2 - z1
        val len = hypot(dx, dz)
        if (len < 0.0001f) return
        val px = -dz / len * w / 2f
        val pz = dx / len * w / 2f
        val y = 0.03f
        quad(x1 - px, y, z1 - pz, x1 + px, y, z1 + pz, x2 + px, y, z2 + pz, x2 - px, y, z2 - pz, 0f, 1f, 0f, c)
    }

    fun box(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, c: FloatArray) {
        val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
        val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
        val z0 = cz - sz / 2f; val z1 = cz + sz / 2f
        quad(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0f, 1f, 0f, c)
        quad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0f, 0f, 1f, c)
        quad(x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, 0f, 0f, -1f, c)
        quad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1f, 0f, 0f, c)
        quad(x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, 1f, 0f, 0f, c)
    }

    fun toMesh(): Mesh = Mesh(a.copyOf(n), 3, null)
}

class GameRenderer(
    private val ctx: Context,
    private val game: Game,
    private val hud: View
) : GLSurfaceView.Renderer {

    private val VS_C = """
        uniform mat4 uMVP; uniform mat4 uModel;
        attribute vec3 aPos; attribute vec3 aNorm; attribute vec3 aCol;
        varying vec3 vCol; varying float vL;
        void main() {
            gl_Position = uMVP * vec4(aPos, 1.0);
            vec3 n = normalize((uModel * vec4(aNorm, 0.0)).xyz);
            vL = 0.55 + 0.5 * max(dot(n, normalize(vec3(0.4, 0.9, 0.5))), 0.0);
            vCol = aCol;
        }
    """.trimIndent()
    private val FS_C = """
        precision mediump float;
        uniform vec3 uTint; uniform float uAlpha;
        varying vec3 vCol; varying float vL;
        void main() { gl_FragColor = vec4(vCol * uTint * vL, uAlpha); }
    """.trimIndent()
    private val VS_T = """
        uniform mat4 uMVP; uniform mat4 uModel;
        uniform float uRun; uniform float uPhase; uniform float uKick;
        attribute vec3 aPos; attribute vec3 aNorm; attribute vec2 aUV;
        varying vec2 vUV; varying float vL; varying float vPY; varying float vPX;
        vec3 rotX(vec3 p, vec3 pv, float a) {
            vec3 d = p - pv;
            float c = cos(a); float s = sin(a);
            return pv + vec3(d.x, d.y * c - d.z * s, d.y * s + d.z * c);
        }
        vec3 rotXn(vec3 n, float a) {
            float c = cos(a); float s = sin(a);
            return vec3(n.x, n.y * c - n.z * s, n.y * s + n.z * c);
        }
        void main() {
            vec3 p = aPos;
            float sw = sin(uPhase) * 0.75 * uRun;
            float kick = sin(uKick * 3.14159) * 1.25;
            float fL = sw;
            float fR = -sw + kick;
            float aL = -fL;
            float aR = -fR;
            float side = smoothstep(-0.02, 0.02, p.x);
            float armW = smoothstep(0.15, 0.19, abs(p.x)) * smoothstep(0.38, 0.44, p.y);
            float legM = (1.0 - smoothstep(0.50, 0.56, p.y)) * (1.0 - armW);
            float wL = legM * side;
            float wR = legM * (1.0 - side);
            float shank = 1.0 - smoothstep(0.24, 0.30, p.y);
            float kL = max(aL, 0.0) * 1.1;
            float kR = max(aR, 0.0) * 1.1;
            vec3 q = p;
            q = mix(q, rotX(q, vec3(0.075, 0.27, 0.0), kL), wL * shank);
            q = mix(q, rotX(q, vec3(0.075, 0.50, 0.0), aL), wL);
            q = mix(q, rotX(q, vec3(-0.075, 0.27, 0.0), kR), wR * shank);
            q = mix(q, rotX(q, vec3(-0.075, 0.50, 0.0), aR), wR);
            float fw = 1.0 - smoothstep(0.58, 0.66, p.y);
            float ae = -uRun * 0.9;
            float wAL = armW * side;
            float wAR = armW * (1.0 - side);
            q = mix(q, rotX(q, vec3(0.22, 0.64, 0.0), ae), wAL * fw);
            q = mix(q, rotX(q, vec3(0.155, 0.80, 0.0), fL * 0.9), wAL);
            q = mix(q, rotX(q, vec3(-0.22, 0.64, 0.0), ae), wAR * fw);
            q = mix(q, rotX(q, vec3(-0.155, 0.80, 0.0), fR * 0.9), wAR);
            vec3 nn = rotXn(aNorm, aL * wL + aR * wR + fL * 0.9 * wAL + fR * 0.9 * wAR);
            gl_Position = uMVP * vec4(q, 1.0);
            vec3 n = normalize((uModel * vec4(nn, 0.0)).xyz);
            vL = 0.6 + 0.55 * max(dot(n, normalize(vec3(0.4, 0.9, 0.5))), 0.0);
            vUV = aUV;
            vPY = aPos.y;
            vPX = aPos.x;
        }
    """.trimIndent()
    private val FS_T = """
        precision mediump float;
        uniform sampler2D uTex; uniform vec3 uTint; uniform float uStyle;
        varying vec2 vUV; varying float vL; varying float vPY; varying float vPX;
        void main() {
            vec3 col = texture2D(uTex, vUV).rgb;
            bool torso = vPY > 0.54 && vPY < 0.87;
            bool redish = col.r > col.g * 1.5 && col.r > col.b * 1.5;
            if (torso && uStyle > 0.5 && uStyle < 1.5 && redish) {
                float band = step(0.5, fract(vPY * 11.0));
                col *= mix(1.0, 0.1, band);
            } else if (torso && uStyle > 1.5 && uStyle < 2.5 && redish) {
                float band = step(0.5, fract(vPX * 25.0));
                float l = col.r;
                col = mix(col, vec3(0.05 * l, 0.5 * l, 1.1 * l), band);
            } else if (torso && uStyle > 2.5 && uStyle < 3.5 && col.b > col.r * 1.8 && col.b > col.g * 1.3) {
                if (abs(vPX) < 0.035) col = vec3(0.9, 0.06, 0.14) * (col.b / 0.38);
            } else if (torso && uStyle > 3.5 && redish && abs(vPX) > 0.165) {
                col = vec3(min(1.0, col.r * 1.15));
            }
            gl_FragColor = vec4(col * uTint * vL, 1.0);
        }
    """.trimIndent()

    private var cProg = 0
    private var tProg = 0
    private var cMVP = 0; private var cModel = 0; private var cTint = 0; private var cAlpha = 0
    private var caPos = 0; private var caNorm = 0; private var caCol = 0
    private var tMVP = 0; private var tModel = 0; private var tTex = 0; private var tTint = 0; private var tRun = 0; private var tPhase = 0; private var tKick = 0; private var tHoops = 0
    private var taPos = 0; private var taNorm = 0; private var taUV = 0

    private lateinit var scene: Mesh
    private lateinit var ball: Mesh
    private lateinit var disc: Mesh
    private lateinit var neymar: Mesh
    private var texId = 0
    private var bgTex = 0
    private val teamTex = IntArray(10)
    private lateinit var bgMesh: Mesh

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val tmp = FloatArray(16)
    private val tmp2 = FloatArray(16)
    private val ballRot = FloatArray(16)
    private var aspect = 2f
    private var last = 0L

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.53f, 0.78f, 0.95f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)

        cProg = link(VS_C, FS_C)
        cMVP = GLES20.glGetUniformLocation(cProg, "uMVP")
        cModel = GLES20.glGetUniformLocation(cProg, "uModel")
        cTint = GLES20.glGetUniformLocation(cProg, "uTint")
        cAlpha = GLES20.glGetUniformLocation(cProg, "uAlpha")
        caPos = GLES20.glGetAttribLocation(cProg, "aPos")
        caNorm = GLES20.glGetAttribLocation(cProg, "aNorm")
        caCol = GLES20.glGetAttribLocation(cProg, "aCol")

        tProg = link(VS_T, FS_T)
        tMVP = GLES20.glGetUniformLocation(tProg, "uMVP")
        tModel = GLES20.glGetUniformLocation(tProg, "uModel")
        tTex = GLES20.glGetUniformLocation(tProg, "uTex")
        tTint = GLES20.glGetUniformLocation(tProg, "uTint")
        tRun = GLES20.glGetUniformLocation(tProg, "uRun")
        tPhase = GLES20.glGetUniformLocation(tProg, "uPhase")
        tKick = GLES20.glGetUniformLocation(tProg, "uKick")
        tHoops = GLES20.glGetUniformLocation(tProg, "uStyle")
        taPos = GLES20.glGetAttribLocation(tProg, "aPos")
        taNorm = GLES20.glGetAttribLocation(tProg, "aNorm")
        taUV = GLES20.glGetAttribLocation(tProg, "aUV")

        scene = buildScene()
        ball = buildBall()
        disc = buildDisc()
        neymar = loadNeymar()
        texId = loadTexture("neymar.png")
        bgTex = loadTexture("menu_bg.jpg")
        teamTex[0] = loadTexture("team_santos.png")
        teamTex[1] = loadTexture("team_fla.png")
        teamTex[2] = loadTexture("team_real.png")
        teamTex[3] = loadTexture("team_barca.png")
        teamTex[4] = loadTexture("team_santos_alt.png")
        teamTex[5] = loadTexture("team_real_alt.png")
        teamTex[6] = loadTexture("team_psg.png")
        teamTex[7] = loadTexture("team_arsenal.png")
        teamTex[8] = loadTexture("team_bayern.png")
        teamTex[9] = loadTexture("team_bvb.png")
        bgMesh = buildBgQuad()
        Matrix.setIdentityM(ballRot, 0)
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        aspect = w.toFloat() / h.toFloat()
    }

    // ------------------------------------------------------------ construcao

    private fun buildScene(): Mesh {
        val b = MB()
        val hl = Game.HL
        val hw = Game.HW
        val gw = Game.GOALW
        val gd = Game.GOALD
        val gh = Game.GOALH

        b.quadY(-45f, -35f, 45f, 35f, -0.03f, floatArrayOf(0.10f, 0.32f, 0.14f))
        val g1 = floatArrayOf(0.20f, 0.56f, 0.24f)
        val g2 = floatArrayOf(0.17f, 0.50f, 0.21f)
        for (i in 0 until 12) {
            val x0 = -hl + i * 2f
            b.quadY(x0, -hw, x0 + 2f, hw, 0f, if (i % 2 == 0) g1 else g2)
        }

        val wh = floatArrayOf(0.95f, 0.95f, 0.95f)
        val lw = 0.12f
        b.line(-hl, -hw, hl, -hw, lw, wh)
        b.line(hl, -hw, hl, hw, lw, wh)
        b.line(hl, hw, -hl, hw, lw, wh)
        b.line(-hl, hw, -hl, -hw, lw, wh)
        b.line(0f, -hw, 0f, hw, lw, wh)
        val seg = 40
        for (i in 0 until seg) {
            val a0 = 2f * Game.PIF * i / seg
            val a1 = 2f * Game.PIF * (i + 1) / seg
            b.line(2.2f * cos(a0), 2.2f * sin(a0), 2.2f * cos(a1), 2.2f * sin(a1), lw, wh)
        }
        for (s in intArrayOf(-1, 1)) {
            val xe = s * hl
            val xp = s * (hl - 3.5f)
            b.line(xe, -4.2f, xp, -4.2f, lw, wh)
            b.line(xp, -4.2f, xp, 4.2f, lw, wh)
            b.line(xp, 4.2f, xe, 4.2f, lw, wh)
            val xg = s * (hl - 1.4f)
            b.line(xe, -3f, xg, -3f, lw, wh)
            b.line(xg, -3f, xg, 3f, lw, wh)
            b.line(xg, 3f, xe, 3f, lw, wh)
        }

        // gols
        val gray = floatArrayOf(0.6f, 0.6f, 0.6f)
        val net = floatArrayOf(0.85f, 0.85f, 0.85f)
        val post = 0.14f
        for (s in intArrayOf(-1, 1)) {
            val gx = s * hl
            val bxk = s * (hl + gd)
            for (zz in floatArrayOf(-gw, gw)) {
                b.box(gx, gh / 2f, zz, post, gh, post, wh)
                b.box(bxk, gh / 2f, zz, post * 0.7f, gh, post * 0.7f, gray)
            }
            b.box(gx, gh, 0f, post, post, gw * 2f + post, wh)
            var z = -gw
            while (z <= gw + 0.01f) { b.box(bxk, gh / 2f, z, 0.03f, gh, 0.03f, net); z += 0.4f }
            var y = 0f
            while (y <= gh + 0.01f) { b.box(bxk, y, 0f, 0.03f, 0.03f, gw * 2f, net); y += 0.4f }
            for (zz in floatArrayOf(-gw, gw)) {
                var x = 0f
                while (x <= gd + 0.01f) { b.box(gx + s * x, gh / 2f, zz, 0.03f, gh, 0.03f, net); x += 0.5f }
                var yy = 0f
                while (yy <= gh + 0.01f) { b.box(gx + s * gd / 2f, yy, zz, gd, 0.03f, 0.03f, net); yy += 0.4f }
            }
            var zr = -gw
            while (zr <= gw + 0.01f) { b.box(gx + s * gd / 2f, gh, zr, gd, 0.03f, 0.03f, net); zr += 0.6f }
        }
        return b.toMesh()
    }

    private fun buildBall(): Mesh {
        val b = MB()
        val r = Game.BR
        val nlat = 10
        val nlon = 14
        val white = floatArrayOf(0.97f, 0.97f, 0.97f)
        val dark = floatArrayOf(0.08f, 0.08f, 0.08f)
        for (i in 0 until nlat) {
            val t0 = Game.PIF * i / nlat
            val t1 = Game.PIF * (i + 1) / nlat
            for (j in 0 until nlon) {
                val f0 = 2f * Game.PIF * j / nlon
                val f1 = 2f * Game.PIF * (j + 1) / nlon
                val c = if ((i + j) % 2 == 0) white else dark
                val ax = sin(t0) * cos(f0); val ay = cos(t0); val az = sin(t0) * sin(f0)
                val bx = sin(t0) * cos(f1); val bz = sin(t0) * sin(f1)
                val cx = sin(t1) * cos(f1); val cy = cos(t1); val cz = sin(t1) * sin(f1)
                val dx = sin(t1) * cos(f0); val dz = sin(t1) * sin(f0)
                b.v(ax * r, ay * r, az * r, ax, ay, az, c)
                b.v(bx * r, ay * r, bz * r, bx, ay, bz, c)
                b.v(cx * r, cy * r, cz * r, cx, cy, cz, c)
                b.v(ax * r, ay * r, az * r, ax, ay, az, c)
                b.v(cx * r, cy * r, cz * r, cx, cy, cz, c)
                b.v(dx * r, cy * r, dz * r, dx, cy, dz, c)
            }
        }
        return b.toMesh()
    }

    private fun buildDisc(): Mesh {
        val b = MB()
        val w = floatArrayOf(1f, 1f, 1f)
        val seg = 24
        for (i in 0 until seg) {
            val a0 = 2f * Game.PIF * i / seg
            val a1 = 2f * Game.PIF * (i + 1) / seg
            b.v(0f, 0f, 0f, 0f, 1f, 0f, w)
            b.v(cos(a0), 0f, sin(a0), 0f, 1f, 0f, w)
            b.v(cos(a1), 0f, sin(a1), 0f, 1f, 0f, w)
        }
        return b.toMesh()
    }

    private fun buildBgQuad(): Mesh {
        val d = floatArrayOf(
            -1f, -1f, 0f, 0f, 0f, 1f, 0f, 1f,
            1f, -1f, 0f, 0f, 0f, 1f, 1f, 1f,
            1f, 1f, 0f, 0f, 0f, 1f, 1f, 0f,
            -1f, 1f, 0f, 0f, 0f, 1f, 0f, 0f
        )
        return Mesh(d, 2, shortArrayOf(0, 1, 2, 0, 2, 3))
    }

    private fun loadNeymar(): Mesh {
        val bytes = ctx.assets.open("neymar.bin").use { it.readBytes() }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val nV = bb.getInt(0)
        val nI = bb.getInt(4)
        val fa = FloatArray(nV * 8)
        bb.position(8)
        bb.asFloatBuffer().get(fa)
        val ia = ShortArray(nI)
        bb.position(8 + nV * 32)
        bb.asShortBuffer().get(ia)
        return Mesh(fa, 2, ia)
    }

    private fun loadTexture(name: String): Int {
        val bmp = ctx.assets.open(name).use { BitmapFactory.decodeStream(it) }
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        bmp.recycle()
        return t[0]
    }

    // ------------------------------------------------------------ desenho

    private fun drawColor(m: Mesh, r: Float, g: Float, b: Float, a: Float) {
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(cMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(cModel, 1, false, model, 0)
        GLES20.glUniform3f(cTint, r, g, b)
        GLES20.glUniform1f(cAlpha, a)
        m.draw(caPos, caNorm, caCol)
    }

    private fun drawPlayer(x: Float, y: Float, z: Float, yaw: Float, lean: Float, roll: Float, scale: Float,
                           run: Float, phase: Float, kick: Float) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.rotateM(model, 0, yaw, 0f, 1f, 0f)
        Matrix.rotateM(model, 0, lean, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, roll, 0f, 0f, 1f)
        Matrix.scaleM(model, 0, scale, scale, scale)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(tMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(tModel, 1, false, model, 0)
        GLES20.glUniform1f(tRun, run)
        GLES20.glUniform1f(tPhase, phase)
        GLES20.glUniform1f(tKick, kick)
        neymar.draw(taPos, taNorm, taUV)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        game.update(dt)

        // rotacao da bola
        val sp = hypot(game.bvx, game.bvz)
        if (sp > 0.05f && game.by <= Game.BR + 0.05f && game.state != Game.MENU) {
            val deg = sp * dt / Game.BR * 180f / Game.PIF
            Matrix.setRotateM(tmp, 0, deg, game.bvz / sp, 0f, -game.bvx / sp)
            Matrix.multiplyMM(tmp2, 0, tmp, 0, ballRot, 0)
            System.arraycopy(tmp2, 0, ballRot, 0, 16)
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val menu = game.state == Game.MENU
        if (menu) {
            Matrix.perspectiveM(proj, 0, 38f, aspect, 1f, 80f)
            Matrix.setLookAtM(view, 0, 0f, 1.6f, 6.5f, 0f, 1.45f, 0f, 0f, 1f, 0f)
        } else {
            val cx = game.bx * 0.25f
            Matrix.perspectiveM(proj, 0, 42f, aspect, 1f, 80f)
            Matrix.setLookAtM(view, 0, cx, 13f, 14f, cx, 0f, 1f, 0f, 1f, 0f)
        }
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        if (menu) drawMenuScene() else { updateHudPoints(); drawGameScene() }
        hud.postInvalidate()
    }

    private val pv = FloatArray(4)
    private val pr = FloatArray(4)
    private var psx = 0f
    private var psy = 0f

    private fun project(x: Float, y: Float, z: Float) {
        pv[0] = x; pv[1] = y; pv[2] = z; pv[3] = 1f
        Matrix.multiplyMV(pr, 0, vp, 0, pv, 0)
        val w = if (pr[3] == 0f) 1f else pr[3]
        psx = pr[0] / w * 0.5f + 0.5f
        psy = 1f - (pr[1] / w * 0.5f + 0.5f)
    }

    private fun updateHudPoints() {
        for (p in 0..1) {
            project(game.px[p], 1.25f + 0.4f, game.pz[p])
            game.headX[p] = psx; game.headY[p] = psy
            project(game.px[p], 0.03f, game.pz[p])
            game.footX[p] = psx; game.footY[p] = psy
            val a = game.yaw[p] * Game.PIF / 180f
            project(game.px[p] + sin(a) * 1.8f, 0.03f, game.pz[p] + cos(a) * 1.8f)
            game.aheadX[p] = psx; game.aheadY[p] = psy
        }
    }

    private fun drawMenuScene() {
        GLES20.glUseProgram(tProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glUniform1i(tTex, 0)

        // fundo (estadio)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bgTex)
        GLES20.glUniform3f(tTint, 0.5f, 0.65f, 0.95f)
        GLES20.glUniform1f(tHoops, 0f)
        Matrix.setIdentityM(model, 0)
        Matrix.setIdentityM(mvp, 0)
        GLES20.glUniformMatrix4fv(tMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(tModel, 1, false, model, 0)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        bgMesh.draw(taPos, taNorm, taUV)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)

        // Neymar do lado esquerdo
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glUniform3f(tTint, 1f, 1f, 1f)
        val yaw = sin(game.time * 0.8f) * 25f
        drawPlayer(-3f, 0f, 0f, yaw, 0f, 0f, 2.7f, 0f, 0f, 0f)

        // bola na mao dele
        GLES20.glUseProgram(cProg)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, -3f, 0f, 0f)
        Matrix.rotateM(model, 0, yaw, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, 2.7f, 2.7f, 2.7f)
        Matrix.translateM(model, 0, 0.285f, 0.50f, 0.09f)
        val k = 0.28f / Game.BR / 2.7f
        Matrix.scaleM(model, 0, k, k, k)
        Matrix.rotateM(model, 0, game.time * 40f, 0.3f, 1f, 0f)
        drawColor(ball, 1f, 1f, 1f, 1f)

        // plataforma brilhante
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, -3f, 0.03f, 0f)
        Matrix.scaleM(model, 0, 1.7f, 1f, 1.7f)
        drawColor(disc, 0.1f, 0.75f, 1f, 0.35f)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, -3f, 0.04f, 0f)
        Matrix.scaleM(model, 0, 1.2f, 1f, 1.2f)
        drawColor(disc, 0.05f, 0.25f, 0.6f, 0.65f)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun drawGameScene() {
        // campo + bola
        GLES20.glUseProgram(cProg)
        Matrix.setIdentityM(model, 0)
        drawColor(scene, 1f, 1f, 1f, 1f)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, game.bx, game.by, game.bz)
        Matrix.multiplyMM(tmp, 0, model, 0, ballRot, 0)
        System.arraycopy(tmp, 0, model, 0, 16)
        drawColor(ball, 1f, 1f, 1f, 1f)

        // jogadores
        GLES20.glUseProgram(tProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glUniform1i(tTex, 0)
        GLES20.glUniform3f(tTint, 1f, 1f, 1f)
        for (p in 0..1) {
            val speed = hypot(game.vx[p], game.vz[p])
            val frac = min(1f, speed / Game.SPEED)
            var bob = abs(sin(game.runPhase[p])) * 0.07f * frac
            val roll = sin(game.runPhase[p]) * 6f * frac
            var lean = 10f * frac
            if (game.kickAnim[p] > 0f) {
                lean += 25f * sin(game.kickAnim[p] / 0.3f * Game.PIF)
            }
            if (game.state == Game.GOAL && game.lastScorer == p) {
                bob = abs(sin(game.time * 9f)) * 0.45f
                lean = -8f
            }
            val tm = game.team[p]
            val light0 = game.team[0] == 0 || game.team[0] == 2
            val light1 = game.team[1] == 0 || game.team[1] == 2
            val alt = p == 1 && light0 && light1
            val ti = if (alt && tm == 0) 4 else if (alt && tm == 2) 5 else if (tm == 4) 6 else if (tm == 5) 7 else if (tm == 6) 8 else if (tm == 7) 9 else tm
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, teamTex[ti])
            GLES20.glUniform1f(tHoops, if (tm == 1) 1f else if (tm == 3) 2f else if (tm == 4) 3f else if (tm == 5) 4f else 0f)
            var run = frac
            var phase = game.runPhase[p]
            if (game.state == Game.GOAL && game.lastScorer == p) {
                run = 0.9f
                phase = game.time * 14f
            }
            val kk = if (game.kickAnim[p] > 0f) 1f - game.kickAnim[p] / 0.3f else 0f
            drawPlayer(game.px[p], bob, game.pz[p], game.yaw[p], lean, roll, 1.25f, run, phase, kk)
        }

        // Elenco visual 11 contra 11: reaproveita o mesmo modelo Neymar para os 20 companheiros.
        // Os dois jogadores principais acima continuam sendo os personagens controlados pela lógica atual.
        val teammateFormation = arrayOf(
            floatArrayOf(-10.2f, 0.0f),
            floatArrayOf(-7.6f, -4.4f), floatArrayOf(-7.9f, -1.5f),
            floatArrayOf(-7.9f, 1.5f), floatArrayOf(-7.6f, 4.4f),
            floatArrayOf(-4.3f, -3.2f), floatArrayOf(-4.3f, 3.2f),
            floatArrayOf(-2.0f, 0.0f),
            floatArrayOf(1.1f, -2.7f), floatArrayOf(1.1f, 2.7f)
        )
        for (side in 0..1) {
            val tm = game.team[side]
            val light0 = game.team[0] == 0 || game.team[0] == 2
            val light1 = game.team[1] == 0 || game.team[1] == 2
            val alt = side == 1 && light0 && light1
            val ti = if (alt && tm == 0) 4 else if (alt && tm == 2) 5 else if (tm == 4) 6 else if (tm == 5) 7 else if (tm == 6) 8 else if (tm == 7) 9 else tm
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, teamTex[ti])
            GLES20.glUniform1f(tHoops, if (tm == 1) 1f else if (tm == 3) 2f else if (tm == 4) 3f else if (tm == 5) 4f else 0f)
            for (slot in teammateFormation.indices) {
                val fx = teammateFormation[slot][0]
                val fz = teammateFormation[slot][1]
                val x = if (side == 0) fx else -fx
                val z = if (side == 0) fz else -fz
                val facing = if (side == 0) 90f else -90f
                val phase = game.time * 1.8f + slot * 0.73f + side * 1.1f
                val bob = abs(sin(phase)) * 0.025f
                drawPlayer(x, bob, z, facing, 0f, 0f, 1.05f, 0f, phase, 0f)
            }
        }

        // sombras e aneis dos times (transparentes)
        GLES20.glUseProgram(cProg)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        for (p in 0..1) {
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, game.px[p], 0.04f, game.pz[p])
            Matrix.scaleM(model, 0, 0.62f, 1f, 0.62f)
            if (p == 0) drawColor(disc, 0.95f, 0.15f, 0.15f, 0.75f)
            else drawColor(disc, 0.15f, 0.45f, 1f, 0.75f)
        }
        val sc = Game.BR * (1f + game.by * 0.15f)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, game.bx, 0.05f, game.bz)
        Matrix.scaleM(model, 0, sc, 1f, sc)
        drawColor(disc, 0f, 0f, 0f, 0.35f)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }
}
