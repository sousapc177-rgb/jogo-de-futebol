package com.futebol.neymar

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.input.InputManager
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class HudView(ctx: Context, private val game: Game, private val onMenu: () -> Unit) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val joyId = intArrayOf(-1, -1)
    private val ox = FloatArray(2)
    private val oy = FloatArray(2)
    private val cx = FloatArray(2)
    private val cy = FloatArray(2)
    private val kickId = intArrayOf(-1, -1)
    private val rematchBtn = RectF()
    private val menuBtn = RectF()
    private val startBtn = RectF()
    private val backBtn = RectF()
    private val rect = RectF()
    private val c1 = 0xFFE53935.toInt()
    private val c2 = 0xFF1E88E5.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val crest = arrayOfNulls<Bitmap>(8)
    private val teamNames = arrayOf("Santos FC", "Flamengo", "Real Madrid", "FC Barcelona", "Paris Saint-Germain", "Arsenal", "Bayern de Munique", "Borussia Dortmund")
    private val tileRects = Array(8) { RectF() }
    private val contBtn = RectF()

    init {
        p.isFilterBitmap = true
        try {
            crest[0] = BitmapFactory.decodeStream(ctx.assets.open("santos.png"))
            crest[1] = BitmapFactory.decodeStream(ctx.assets.open("flamengo.png"))
            crest[2] = BitmapFactory.decodeStream(ctx.assets.open("realmadrid.png"))
            crest[3] = BitmapFactory.decodeStream(ctx.assets.open("barcelona.png"))
            crest[4] = BitmapFactory.decodeStream(ctx.assets.open("psg.png"))
            crest[5] = BitmapFactory.decodeStream(ctx.assets.open("arsenal.png"))
            crest[6] = BitmapFactory.decodeStream(ctx.assets.open("bayern.png"))
            crest[7] = BitmapFactory.decodeStream(ctx.assets.open("bvb.png"))
        } catch (e: Exception) {
        }
    }

    private fun drawCrest(c: Canvas, idx: Int, cxp: Float, cyp: Float, size: Float) {
        val b = crest[idx] ?: return
        val sc = size / max(b.width, b.height).toFloat()
        val bw = b.width * sc
        val bh = b.height * sc
        rect.set(cxp - bw / 2f, cyp - bh / 2f, cxp + bw / 2f, cyp + bh / 2f)
        p.style = Paint.Style.FILL
        p.color = white
        c.drawBitmap(b, null, rect, p)
    }

    private var pesMenu: PesMenu? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val parent = parent as? android.view.ViewGroup ?: return
        if (pesMenu != null) return
        // troca o menu antigo pelo menu novo estilo PES
        val me = parent.indexOfChild(this)
        while (parent.childCount > me + 1) parent.removeViewAt(me + 1)
        val m = PesMenu(context, game, this)
        pesMenu = m
        parent.addView(m, android.widget.FrameLayout.LayoutParams(-1, -1))
        m.visibility = if (visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (changedView !== this) return
        val m = pesMenu ?: return
        if (visibility == View.VISIBLE) m.visibility = View.GONE
        else { m.refresh(); m.visibility = View.VISIBLE }
    }

    fun reset() {
        for (i in 0..1) {
            joyId[i] = -1; kickId[i] = -1
            game.joyX[i] = 0f; game.joyY[i] = 0f
            game.kickTouch[i] = false
        }
    }

    private fun joyR() = height * 0.17f
    private fun kx(i: Int) = if (game.vsAI) width * 0.88f else if (i == 0) width * 0.40f else width * 0.60f
    private fun ky() = height * 0.80f
    private fun kr() = height * 0.10f
    private fun hx(i: Int) = if (i == 0) width * 0.13f else width * 0.87f
    private fun hy() = height * 0.72f
    private fun teamColor(i: Int) = if (i == 0) c1 else c2
    private fun nm(i: Int) = if (i == 1 && game.vsAI) "CPU" else "J" + (i + 1)
    private fun usesTouch(i: Int) = !(game.vsAI && i == 1) && !game.padFor(i)
    private fun alpha(col: Int, a: Int) = (col and 0x00FFFFFF) or (a shl 24)

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = size
        p.color = color
        p.setShadowLayer(size * 0.06f, 0f, size * 0.04f, 0xAA000000.toInt())
        c.drawText(s, x, y, p)
        p.clearShadowLayer()
    }

    override fun onDraw(c: Canvas) {
        val st = game.state
        if (st == Game.MENU) return
        val w = width.toFloat()
        val h = height.toFloat()

        if (st == Game.CONTROLS) {
            drawControlsScreen(c, w, h)
            return
        }
        if (st == Game.TEAMSEL) {
            drawTeamScreen(c, w, h)
            return
        }

        // placar
        rect.set(w * 0.30f, h * 0.02f, w * 0.70f, h * 0.20f)
        p.style = Paint.Style.FILL
        p.color = 0x99000000.toInt()
        c.drawRoundRect(rect, h * 0.04f, h * 0.04f, p)
        drawCrest(c, game.team[0], w * 0.325f, h * 0.11f, h * 0.13f)
        drawCrest(c, game.team[1], w * 0.675f, h * 0.11f, h * 0.13f)
        txt(c, nm(0), w * 0.405f, h * 0.115f, h * 0.05f, c1)
        txt(c, nm(1), w * 0.595f, h * 0.115f, h * 0.05f, c2)
        txt(c, "${game.score[0]} - ${game.score[1]}", w * 0.5f, h * 0.125f, h * 0.095f, white)
        val secs = ceil(game.timeLeft).toInt()
        txt(c, String.format("%d:%02d", secs / 60, secs % 60), w * 0.5f, h * 0.185f, h * 0.05f, 0xFFFFD500.toInt())

        if (st == Game.PLAY || st == Game.KICKOFF) drawCursors(c, w, h)
        if (st != Game.END) drawTouchControls(c)

        if (st == Game.KICKOFF) {
            val n = ceil(game.stateTimer).toInt().coerceIn(1, 3)
            txt(c, n.toString(), w * 0.5f, h * 0.55f, h * 0.28f, white)
        } else if (st == Game.GOAL) {
            txt(c, "GOOOL!", w * 0.5f, h * 0.50f, h * 0.22f, 0xFFFFD500.toInt())
            if (game.lastScorer >= 0) {
                txt(c, nm(game.lastScorer) + " marcou!", w * 0.5f, h * 0.62f, h * 0.07f, teamColor(game.lastScorer))
            }
        } else if (st == Game.END) {
            p.style = Paint.Style.FILL
            p.color = 0xBB000000.toInt()
            c.drawRect(0f, 0f, w, h, p)
            txt(c, "FIM DE JOGO", w * 0.5f, h * 0.28f, h * 0.12f, white)
            txt(c, "${game.score[0]} - ${game.score[1]}", w * 0.5f, h * 0.50f, h * 0.16f, 0xFFFFD500.toInt())
            val s0 = game.score[0]
            val s1 = game.score[1]
            if (s0 == s1) txt(c, "EMPATE!", w * 0.5f, h * 0.61f, h * 0.07f, white)
            else {
                val win = if (s0 > s1) 0 else 1
                txt(c, nm(win) + " GANHOU!", w * 0.5f, h * 0.61f, h * 0.07f, teamColor(win))
            }
            val bw = w * 0.22f
            val bh = h * 0.14f
            val gap = w * 0.03f
            rematchBtn.set(w * 0.5f - bw - gap / 2f, h * 0.68f, w * 0.5f - gap / 2f, h * 0.68f + bh)
            menuBtn.set(w * 0.5f + gap / 2f, h * 0.68f, w * 0.5f + gap / 2f + bw, h * 0.68f + bh)
            p.style = Paint.Style.FILL
            p.color = 0xFF2E9E3F.toInt()
            c.drawRoundRect(rematchBtn, bh / 2f, bh / 2f, p)
            p.color = 0xFF555555.toInt()
            c.drawRoundRect(menuBtn, bh / 2f, bh / 2f, p)
            txt(c, "REVANCHE", rematchBtn.centerX(), rematchBtn.centerY() + h * 0.02f, h * 0.06f, white)
            txt(c, "MENU", menuBtn.centerX(), menuBtn.centerY() + h * 0.02f, h * 0.06f, white)
        }
    }

    // cursor estilo PES: triangulo sobre o jogador, seta de direcao e barra de forca
    private fun drawCursors(c: Canvas, w: Float, h: Float) {
        for (i in 0..1) {
            if (game.vsAI && i == 1) continue
            val col = teamColor(i)
            val hx = game.headX[i] * w
            val hy = game.headY[i] * h
            val s = h * 0.024f
            val bob = sin(game.time * 6f) * s * 0.25f
            path.reset()
            path.moveTo(hx - s, hy - s + bob)
            path.lineTo(hx + s, hy - s + bob)
            path.lineTo(hx, hy + s * 0.7f + bob)
            path.close()
            p.style = Paint.Style.FILL
            p.color = col
            c.drawPath(path, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.2f
            p.color = white
            c.drawPath(path, p)

            // seta no chao na direcao do movimento
            val sp = hypot(game.vx[i], game.vz[i])
            if (sp > 0.8f) {
                val fx = game.footX[i] * w
                val fy = game.footY[i] * h
                val axp = game.aheadX[i] * w
                val ayp = game.aheadY[i] * h
                var dx = axp - fx
                var dy = ayp - fy
                val len = hypot(dx, dy)
                if (len > 1f) {
                    dx /= len; dy /= len
                    val a = h * 0.035f
                    val nx = -dy
                    val ny = dx
                    path.reset()
                    path.moveTo(axp + dx * a, ayp + dy * a)
                    path.lineTo(axp - dx * a * 0.5f + nx * a * 0.9f, ayp - dy * a * 0.5f + ny * a * 0.9f)
                    path.lineTo(axp - dx * a * 0.1f, ayp - dy * a * 0.1f)
                    path.lineTo(axp - dx * a * 0.5f - nx * a * 0.9f, ayp - dy * a * 0.5f - ny * a * 0.9f)
                    path.close()
                    p.style = Paint.Style.FILL
                    p.color = alpha(col, 0xDD)
                    c.drawPath(path, p)
                }
            }

            // barra de forca do chute (verde -> vermelho)
            val ch = game.charge[i]
            if (ch > 0.04f) {
                val bw = h * 0.22f
                val bh = h * 0.024f
                val bl = game.footX[i] * w - bw / 2f
                val bt = game.footY[i] * h + h * 0.045f
                rect.set(bl - 3f, bt - 3f, bl + bw + 3f, bt + bh + 3f)
                p.style = Paint.Style.FILL
                p.color = 0xCC000000.toInt()
                c.drawRoundRect(rect, bh, bh, p)
                p.shader = LinearGradient(
                    bl, 0f, bl + bw, 0f,
                    intArrayOf(0xFF2ECC40.toInt(), 0xFFFFDC00.toInt(), 0xFFFF4136.toInt()),
                    null, Shader.TileMode.CLAMP
                )
                c.save()
                c.clipRect(bl, bt, bl + bw * ch, bt + bh)
                rect.set(bl, bt, bl + bw, bt + bh)
                c.drawRoundRect(rect, bh / 2f, bh / 2f, p)
                c.restore()
                p.shader = null
            }
        }
    }

    private fun drawTouchControls(c: Canvas) {
        val r = joyR()
        for (i in 0..1) {
            if (!usesTouch(i)) continue
            val col = teamColor(i)
            p.style = Paint.Style.STROKE
            p.strokeWidth = height * 0.008f
            if (joyId[i] == -1) {
                p.color = alpha(col, 0x55)
                c.drawCircle(hx(i), hy(), r, p)
                txt(c, nm(i), hx(i), hy() + height * 0.025f, height * 0.07f, alpha(col, 0x66))
            } else {
                p.color = alpha(col, 0x88)
                c.drawCircle(ox[i], oy[i], r, p)
                p.style = Paint.Style.FILL
                p.color = alpha(col, 0xAA)
                c.drawCircle(cx[i], cy[i], r * 0.4f, p)
            }
            p.style = Paint.Style.FILL
            val pressed = kickId[i] != -1
            p.color = alpha(col, if (pressed) 0xDD else 0x88)
            c.drawCircle(kx(i), ky(), kr(), p)
            txt(c, "CHUTAR", kx(i), ky() + kr() * 0.14f, kr() * 0.38f, white)
        }
    }

    private fun shorten(s: String) = if (s.length > 24) s.substring(0, 24) + ".." else s

    private fun drawPadIcon(c: Canvas, x: Float, y: Float, size: Float, on: Boolean, col: Int) {
        val bw = size
        val bh = size * 0.55f
        rect.set(x - bw / 2f, y - bh / 2f, x + bw / 2f, y + bh / 2f)
        p.style = Paint.Style.FILL
        p.color = if (on) col else 0xFF4A5268.toInt()
        c.drawRoundRect(rect, bh * 0.45f, bh * 0.45f, p)
        p.color = 0xFF18213B.toInt()
        val dx = x - bw * 0.24f
        val dy = y - bh * 0.05f
        c.drawRect(dx - bw * 0.09f, dy - bh * 0.045f, dx + bw * 0.09f, dy + bh * 0.045f, p)
        c.drawRect(dx - bh * 0.045f, dy - bw * 0.09f, dx + bh * 0.045f, dy + bw * 0.09f, p)
        c.drawCircle(x + bw * 0.22f, y - bh * 0.12f, bh * 0.08f, p)
        c.drawCircle(x + bw * 0.31f, y + bh * 0.08f, bh * 0.08f, p)
    }

    private fun txtL(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = size
        p.color = color
        p.setShadowLayer(size * 0.06f, 0f, size * 0.04f, 0xAA000000.toInt())
        c.drawText(s, x, y, p)
        p.clearShadowLayer()
    }

    private fun drawTeamScreen(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF061450.toInt(), 0xFF0A2A9A.toInt(), 0xFF040C33.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        val cur = game.cursor
        val sel = game.selecting
        val selCol = teamColor(sel)
        drawCrest(c, cur, w * 0.07f, h * 0.17f, h * 0.17f)
        txtL(c, teamNames[cur], w * 0.14f, h * 0.20f, h * 0.10f, 0xFFFFE900.toInt())
        val label = if (sel == 1 && game.vsAI) "ESCOLHA O TIME DA CPU" else nm(sel) + ", ESCOLHA SEU TIME"
        txtL(c, label, w * 0.14f, h * 0.30f, h * 0.045f, selCol)

        if (sel == 1) {
            drawCrest(c, game.team[0], w * 0.92f, h * 0.15f, h * 0.13f)
            txt(c, "J1", w * 0.92f, h * 0.265f, h * 0.045f, c1)
        }

        val ts = h * 0.20f
        val gap = h * 0.03f
        for (t in 0 until Game.TEAMS) {
            val x = w * 0.06f + (t % 4) * (ts + gap)
            val y = h * 0.37f + (t / 4) * (ts + gap)
            tileRects[t].set(x, y, x + ts, y + ts)
            val hl = t == cur
            val taken = sel == 1 && t == game.team[0]
            p.style = Paint.Style.FILL
            p.color = if (hl) white else 0xFF2A2A2E.toInt()
            c.drawRoundRect(tileRects[t], h * 0.03f, h * 0.03f, p)
            if (hl) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = h * 0.008f
                p.color = 0xFF9FB8FF.toInt()
                c.drawRoundRect(tileRects[t], h * 0.03f, h * 0.03f, p)
            }
            drawCrest(c, t, x + ts / 2f, y + ts / 2f, ts * 0.72f)
            if (taken) {
                p.style = Paint.Style.FILL
                p.color = 0xAA000000.toInt()
                c.drawRoundRect(tileRects[t], h * 0.03f, h * 0.03f, p)
                txt(c, "J1", x + ts / 2f, y + ts * 0.62f, h * 0.05f, c1)
            }
        }

        txt(c, "Toque num time e depois em ESCOLHER. Controle: esquerda/direita move, A escolhe, B volta",
            w * 0.5f, h * 0.845f, h * 0.03f, 0xFFB0B8CC.toInt())
        val bw = w * 0.22f
        val bh = h * 0.095f
        backBtn.set(w * 0.05f, h * 0.885f, w * 0.05f + bw, h * 0.885f + bh)
        contBtn.set(w * 0.05f + bw + w * 0.03f, h * 0.885f, w * 0.05f + 2f * bw + w * 0.03f, h * 0.885f + bh)
        p.style = Paint.Style.FILL
        p.color = 0xFF1E3FD8.toInt()
        c.drawRoundRect(backBtn, bh / 2f, bh / 2f, p)
        p.color = 0xFF2E9E3F.toInt()
        c.drawRoundRect(contBtn, bh / 2f, bh / 2f, p)
        txt(c, "VOLTAR", backBtn.centerX(), backBtn.centerY() + h * 0.018f, h * 0.05f, white)
        txt(c, "ESCOLHER", contBtn.centerX(), contBtn.centerY() + h * 0.018f, h * 0.05f, white)
    }

    private fun drawControlsScreen(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = 0xCC000000.toInt()
        c.drawRect(0f, 0f, w, h, p)
        txt(c, "CONTROLES", w * 0.5f, h * 0.13f, h * 0.085f, white)
        for (i in 0..1) {
            val l = if (i == 0) w * 0.07f else w * 0.52f
            val r = l + w * 0.41f
            val mid = (l + r) / 2f
            val col = teamColor(i)
            rect.set(l, h * 0.19f, r, h * 0.68f)
            p.style = Paint.Style.FILL
            p.color = 0xFF18213B.toInt()
            c.drawRoundRect(rect, h * 0.03f, h * 0.03f, p)
            rect.set(l, h * 0.19f, r, h * 0.29f)
            p.color = col
            c.drawRoundRect(rect, h * 0.03f, h * 0.03f, p)
            txt(c, nm(i) + (if (i == 0) "  VERMELHO" else "  AZUL"), mid, h * 0.265f, h * 0.055f, white)

            val cpu = game.vsAI && i == 1
            val pad = game.padFor(i)
            var status = ""
            var sub = ""
            if (cpu) {
                txt(c, "IA", mid, h * 0.5f, h * 0.16f, 0xFF8FA0B8.toInt())
                status = "CPU (IA)"; sub = "controlado pelo celular"
            } else {
                drawPadIcon(c, mid, h * 0.43f, h * 0.30f, pad, col)
                if (pad) { status = shorten(game.padName(i)); sub = "controle conectado" }
                else { status = "Sem controle"; sub = "joga pelo toque na tela" }
            }
            txt(c, status, mid, h * 0.565f, h * 0.05f, white)
            txt(c, sub, mid, h * 0.64f, h * 0.035f, 0xFFB0B8CC.toInt())
        }
        txt(c, "Conecte controles Xbox ou PS5: o 1o vira J1 (vermelho) e o 2o vira J2 (azul)", w * 0.5f, h * 0.75f, h * 0.032f, 0xFFB0B8CC.toInt())

        val bw = w * 0.24f
        val bh = h * 0.13f
        startBtn.set(w * 0.52f, h * 0.80f, w * 0.52f + bw, h * 0.80f + bh)
        backBtn.set(w * 0.48f - bw, h * 0.80f, w * 0.48f, h * 0.80f + bh)
        p.style = Paint.Style.FILL
        p.color = 0xFF2E9E3F.toInt()
        c.drawRoundRect(startBtn, bh / 2f, bh / 2f, p)
        p.color = 0xFF555555.toInt()
        c.drawRoundRect(backBtn, bh / 2f, bh / 2f, p)
        txt(c, "COMECAR", startBtn.centerX(), startBtn.centerY() + h * 0.02f, h * 0.055f, white)
        txt(c, "VOLTAR", backBtn.centerX(), backBtn.centerY() + h * 0.02f, h * 0.055f, white)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val st = game.state
        if (st == Game.END) {
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                if (rematchBtn.contains(e.x, e.y)) game.pendingStart = true
                else if (menuBtn.contains(e.x, e.y)) onMenu()
            }
            return true
        }
        if (st == Game.CONTROLS) {
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                if (startBtn.contains(e.x, e.y)) game.pendingStart = true
                else if (backBtn.contains(e.x, e.y)) game.state = Game.TEAMSEL
            }
            return true
        }
        if (st == Game.TEAMSEL) {
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                var hit = -1
                for (t in 0 until Game.TEAMS) if (tileRects[t].contains(e.x, e.y)) hit = t
                if (hit >= 0) {
                    if (game.cursor == hit) game.confirmTeam() else game.cursor = hit
                } else if (contBtn.contains(e.x, e.y)) game.confirmTeam()
                else if (backBtn.contains(e.x, e.y)) { if (game.backTeam()) onMenu() }
            }
            return true
        }
        if (st == Game.MENU) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> reset()
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        for (i in 0..1) {
            if (!usesTouch(i)) continue
            if (hypot(x - kx(i), y - ky()) < kr() * 1.3f) {
                kickId[i] = id
                game.kickTouch[i] = true
                return
            }
        }
        val i = if (x < width * 0.5f) 0 else 1
        if (!usesTouch(i)) return
        if (joyId[i] == -1) {
            joyId[i] = id
            ox[i] = x; oy[i] = y; cx[i] = x; cy[i] = y
            game.joyX[i] = 0f; game.joyY[i] = 0f
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        for (i in 0..1) {
            if (joyId[i] == id) {
                val r = joyR()
                var dx = x - ox[i]
                var dy = y - oy[i]
                val len = hypot(dx, dy)
                if (len > r) { dx = dx / len * r; dy = dy / len * r }
                cx[i] = ox[i] + dx
                cy[i] = oy[i] + dy
                if (len < r * 0.15f) { game.joyX[i] = 0f; game.joyY[i] = 0f }
                else { game.joyX[i] = dx / r; game.joyY[i] = dy / r }
            }
        }
    }

    private fun up(id: Int) {
        for (i in 0..1) {
            if (joyId[i] == id) { joyId[i] = -1; game.joyX[i] = 0f; game.joyY[i] = 0f }
            if (kickId[i] == id) { kickId[i] = -1; game.kickTouch[i] = false }
        }
    }
}

/** Menu inicial estilo PES 2017. Fica por cima do jogo e some quando a partida comeca. */
class PesMenu(private val ctx: Context, private val game: Game, private val hud: HudView) : FrameLayout(ctx) {
    private val times = intArrayOf(60, 120, 180)
    private var timeIdx = 1
    private lateinit var timeChip: TextView

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = true): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        return t
    }

    private fun circle(text: String, color: Int, sizeDp: Int): TextView {
        val t = tv(text, 12f, Color.WHITE)
        t.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        t.background = g
        t.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return t
    }

    init { build() }

    private fun showControls() {
        AlertDialog.Builder(ctx)
            .setTitle("Controles")
            .setMessage("Toque: J1 joga no lado esquerdo da tela e J2 no lado direito. Arrasta o dedo pra correr e segura CHUTAR pra carregar a forca.\n\nControle Xbox ou PS5: analogico/direcional corre, A/X (ou R1/R2) chuta. O 1o controle conectado e o J1 (vermelho) e o 2o e o J2 (azul).\n\nModelo 3D: sulavkhdka (CC BY 4.0).")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showCredits() {
        AlertDialog.Builder(ctx)
            .setTitle("Creditos")
            .setMessage("Modelo 3D: \"Neymar 3d model\" por sulavkhdka (CC BY 4.0).")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun finish() { (ctx as? Activity)?.finish() }

    private fun startGame(ai: Boolean) {
        game.matchSeconds = times[timeIdx]
        hud.reset()
        game.enterTeamSelect(ai)
        hud.visibility = View.VISIBLE
    }

    /** chamado pelo HudView quando volta pro menu */
    fun refresh() { updateTime(); renderCards() }

    // ---------- menu estilo PES 2017 ----------
    private lateinit var cardsRow: LinearLayout
    private lateinit var tabHome: TextView
    private lateinit var tabExtras: TextView
    private lateinit var tipText: TextView
    private var tab = 0
    private var sel = 0

    private class Item(
        val title: String, val desc: String, val icon: String,
        val top: Int, val bottom: Int, val art: () -> View, val tip: String, val action: () -> Unit
    )

    private fun crest(name: String, sizeDp: Int): View {
        val v = android.widget.ImageView(ctx)
        try {
            ctx.assets.open(name).use { v.setImageBitmap(android.graphics.BitmapFactory.decodeStream(it)) }
        } catch (e: Exception) { }
        v.scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
            setMargins(dp(6), 0, dp(6), 0)
        }
        return v
    }

    private fun artRow(vararg views: View): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER
        for (v in views) r.addView(v)
        return r
    }

    private fun bigText(t: String, sp: Float): TextView {
        val x = tv(t, sp, Color.WHITE)
        x.gravity = Gravity.CENTER
        x.setShadowLayer(8f, 0f, 3f, 0x99000000.toInt())
        return x
    }

    private fun items(): List<Item> = if (tab == 0) listOf(
        Item("2 JOGADORES", "Jogue 1 x 1 no mesmo celular. Bora ver quem e o craque!", "\u25B6",
            0xFFFFC21A.toInt(), 0xFFB24A00.toInt(),
            { artRow(crest("flamengo.png", 70), bigText("x", 22f), crest("santos.png", 70)) },
            "Toque no cartao pra escolher os times e jogar com um amigo.") { startGame(false) },
        Item("CONTRA A IA", "Enfrente o computador. A partida nao e salva.", "\u2605",
            0xFF9B1B30.toInt(), 0xFF2A0A22.toInt(),
            { artRow(crest("barcelona.png", 70), bigText("VS", 20f), crest("bvb.png", 70)) },
            "Voce e o J1 (vermelho) e o computador joga de azul.") { startGame(true) },
        Item("TEMPO DE JOGO", "Toque pra mudar a duracao da partida.", "\u25F7",
            0xFF2E9E4F.toInt(), 0xFF0B3B2A.toInt(),
            { bigText(times[timeIdx].div(60).toString() + ":00", 38f) },
            "Voce pode escolher 1, 2 ou 3 minutos de jogo.") { cycleTime(); renderCards() }
    ) else listOf(
        Item("CONTROLES", "Veja como jogar no toque e no controle.", "?",
            0xFF3A7BFF.toInt(), 0xFF12306B.toInt(), { bigText("?", 44f) },
            "Aceita controle Xbox ou PS5 por Bluetooth ou cabo.") { showControls() },
        Item("CREDITOS", "Quem fez o modelo 3D do Neymar.", "\u00A9",
            0xFF6A4CC2.toInt(), 0xFF1E1448.toInt(), { bigText("\u00A9", 44f) },
            "Modelo 3D por sulavkhdka (CC BY 4.0).") { showCredits() },
        Item("SAIR", "Fechar o jogo.", "\u2715",
            0xFF555F70.toInt(), 0xFF1A1F29.toInt(), { bigText("X", 44f) },
            "Ate a proxima, craque!") { finish() }
    )

    private fun renderCards() {
        cardsRow.removeAllViews()
        val list = items()
        if (sel >= list.size) sel = 0
        tipText.text = list[sel].tip
        tabHome.setTextColor(if (tab == 0) 0xFF0B2A5A.toInt() else Color.WHITE)
        tabHome.background = rounded(if (tab == 0) 0xFFF2F6FC.toInt() else 0x331B4F9A, 2)
        tabExtras.setTextColor(if (tab == 1) 0xFF0B2A5A.toInt() else Color.WHITE)
        tabExtras.background = rounded(if (tab == 1) 0xFFF2F6FC.toInt() else 0x331B4F9A, 2)

        list.forEachIndexed { i, it ->
            val selected = i == sel
            val c = LinearLayout(ctx)
            c.orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, -1, 1f)
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            c.layoutParams = lp
            c.background = rounded(if (selected) 0xFF1E6FE8.toInt() else 0xFFE4EAF4.toInt(), 3)
            c.clipToOutline = true

            // parte de cima (arte)
            val artBox = FrameLayout(ctx)
            artBox.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(it.top, it.bottom)
            )
            val art = it.art()
            artBox.addView(art, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            val ic = circle(it.icon, 0xFF0B2A5A.toInt(), 30)
            ic.textSize = 13f
            val ib = rounded(Color.WHITE, 15)
            ib.shape = GradientDrawable.OVAL
            ic.background = ib
            ic.setTextColor(0xFF0B2A5A.toInt())
            artBox.addView(ic, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(8), dp(8))
            })
            c.addView(artBox, LinearLayout.LayoutParams(-1, 0, 1.5f))

            // parte de baixo (texto)
            val box = LinearLayout(ctx)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(12), dp(8), dp(12), dp(8))
            box.addView(tv(it.title, 15f, if (selected) Color.WHITE else 0xFF16356B.toInt()))
            val d = tv(it.desc, 10.5f, if (selected) 0xFFE6F0FF.toInt() else 0xFF45546E.toInt(), false)
            d.setPadding(0, dp(4), 0, 0)
            box.addView(d)
            c.addView(box, LinearLayout.LayoutParams(-1, 0, 1f))

            c.setOnClickListener { _ ->
                if (sel == i) it.action() else { sel = i; renderCards() }
            }
            cardsRow.addView(c)
        }
    }

    private fun setTab(t: Int) { tab = t; sel = 0; renderCards() }

    private fun build() {
        val root = this
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF4FB4F7.toInt(), 0xFF1767C9.toInt(), 0xFF0A3E94.toInt())
        )
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(8), dp(14), dp(6))

        // linha de cima: logo + moedas + avatar
        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = tv("NEYMAR", 20f, Color.WHITE)
        logo.setShadowLayer(4f, 0f, 2f, 0x88000000.toInt())
        val logo2 = tv("FUTEBOL", 20f, 0xFFFF4D4D.toInt())
        logo2.setPadding(dp(6), 0, 0, 0)
        top.addView(logo); top.addView(logo2)
        top.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        timeChip = tv("", 12f, Color.WHITE)
        timeChip.gravity = Gravity.CENTER
        timeChip.setPadding(dp(14), dp(4), dp(14), dp(4))
        timeChip.background = rounded(0x66051A44, 14)
        timeChip.setOnClickListener { cycleTime(); renderCards() }
        top.addView(timeChip)
        val av = circle("NJ", 0xFF1E6FE0.toInt(), 30)
        (av.layoutParams as LinearLayout.LayoutParams).leftMargin = dp(10)
        top.addView(av)
        col.addView(top, LinearLayout.LayoutParams(-1, dp(40)))

        // abas HOME / EXTRAS
        val tabs = LinearLayout(ctx)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.gravity = Gravity.CENTER_VERTICAL
        fun tabView(label: String, t: Int): TextView {
            val x = tv(label, 12f, Color.WHITE)
            x.gravity = Gravity.CENTER
            x.setOnClickListener { setTab(t) }
            tabs.addView(x, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            return x
        }
        tabHome = tabView("HOME", 0)
        tabExtras = tabView("EXTRAS", 1)
        col.addView(tabs, LinearLayout.LayoutParams(-1, dp(26)).apply { topMargin = dp(4); bottomMargin = dp(4) })

        // cartoes
        cardsRow = LinearLayout(ctx)
        cardsRow.orientation = LinearLayout.HORIZONTAL
        col.addView(cardsRow, LinearLayout.LayoutParams(-1, 0, 1f))

        // dica
        tipText = tv("", 11f, Color.WHITE, false)
        tipText.setSingleLine(true)
        tipText.gravity = Gravity.CENTER_VERTICAL
        tipText.setPadding(dp(4), 0, 0, 0)
        val tipRow = LinearLayout(ctx)
        tipRow.orientation = LinearLayout.HORIZONTAL
        tipRow.gravity = Gravity.CENTER_VERTICAL
        val dot = circle("i", 0xFF18C0E8.toInt(), 16)
        dot.textSize = 9f
        tipRow.addView(dot)
        tipRow.addView(tipText)
        col.addView(tipRow, LinearLayout.LayoutParams(-1, dp(24)))

        // Ajuda / Confirmar
        val hints = LinearLayout(ctx)
        hints.orientation = LinearLayout.HORIZONTAL
        hints.gravity = Gravity.CENTER_VERTICAL
        fun hint(btn: String, label: String, action: () -> Unit) {
            val b = tv(btn, 10f, Color.WHITE)
            b.gravity = Gravity.CENTER
            b.setPadding(dp(8), dp(2), dp(8), dp(2))
            b.background = rounded(0xFF4B5563.toInt(), 3)
            val l = tv(label, 12f, Color.WHITE, false)
            l.setPadding(dp(6), 0, dp(18), 0)
            val g = LinearLayout(ctx)
            g.orientation = LinearLayout.HORIZONTAL
            g.gravity = Gravity.CENTER_VERTICAL
            g.addView(b); g.addView(l)
            g.setOnClickListener { action() }
            hints.addView(g)
        }
        hint("?", "Ajuda") { showControls() }
        hint("OK", "Confirmar") { items()[sel].action() }
        col.addView(hints, LinearLayout.LayoutParams(-1, dp(28)))

        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        updateTime()
        renderCards()
    }

    private fun cycleTime() {
        timeIdx = (timeIdx + 1) % times.size
        updateTime()
    }

    private fun updateTime() {
        val label = (times[timeIdx] / 60).toString() + ":00"
        timeChip.text = "TEMPO  $label"
    }

}
