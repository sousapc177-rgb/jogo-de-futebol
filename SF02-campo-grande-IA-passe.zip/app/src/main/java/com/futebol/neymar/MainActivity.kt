package com.futebol.neymar

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.hardware.input.InputManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val game = Game()
    private lateinit var glView: GLSurfaceView
    private lateinit var hud: HudView
    private lateinit var menu: View
    private lateinit var timeText: TextView
    private lateinit var timeChip: TextView
    private val times = intArrayOf(60, 120, 180)
    private var timeIdx = 1
    private val lastDir = IntArray(2)
    private val menuCards = ArrayList<LinearLayout>()
    private val menuActions = ArrayList<() -> Unit>()
    private var menuSelection = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val root = FrameLayout(this)

        hud = HudView(this, game) { showMenu() }
        hud.visibility = View.GONE

        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        glView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        glView.setRenderer(GameRenderer(this, game, hud))

        menu = buildMenu()

        root.addView(glView, FrameLayout.LayoutParams(-1, -1))
        root.addView(hud, FrameLayout.LayoutParams(-1, -1))
        root.addView(menu, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    // ------------------------------------------------------------ menu

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = true): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        return t
    }

    private fun circle(text: String, color: Int, sizeDp: Int): TextView {
        val t = tv(text, 12f, Color.WHITE)
        t.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        t.background = g
        t.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return t
    }

    private fun card(bg: Int, weight: Float, onClick: (() -> Unit)?): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), dp(10), dp(12), dp(10))
        c.background = rounded(bg, 6)
        val lp = LinearLayout.LayoutParams(-1, 0, weight)
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        c.layoutParams = lp
        if (onClick != null) c.setOnClickListener { onClick() }
        return c
    }

    private fun buildMenu(): View {
        val root = FrameLayout(this)
        val white = Color.WHITE
        val muted = 0xFFB8CBEA.toInt()
        val blue = 0xFF1675E8.toInt()
        val dark = 0xFF071B43.toInt()
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF061A43.toInt(), 0xFF123C78.toInt(), 0xFF087FA8.toInt())
        )

        // brilho discreto no fundo, inspirado no menu do PES 2017
        val glow = View(this)
        glow.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x332A9BFF, 0x002A9BFF)
        )
        root.addView(glow, FrameLayout.LayoutParams(-1, -1))

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(18), dp(10), dp(18), dp(8))
        root.addView(page, FrameLayout.LayoutParams(-1, -1))

        // topo: marca SF e moedas/temporada
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = tv("SF", 27f, white)
        logo.setShadowLayer(dp(3).toFloat(), 0f, dp(2).toFloat(), 0xAA000000.toInt())
        top.addView(logo)
        val edition = tv("02", 27f, 0xFFFF3D4F.toInt())
        edition.setPadding(dp(2), 0, 0, 0)
        top.addView(edition)
        val season = tv("  FOOTBALL", 11f, muted)
        season.gravity = Gravity.CENTER_VERTICAL
        top.addView(season)
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val seasonChip = tv("●  TEMPORADA 2026", 11f, white)
        seasonChip.setPadding(dp(12), dp(7), dp(12), dp(7))
        seasonChip.background = rounded(0x552B6FC2, 18)
        top.addView(seasonChip)
        page.addView(top, LinearLayout.LayoutParams(-1, dp(42)))

        // abas HOME / EXTRAS
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(0, dp(8), 0, dp(10))
        fun tab(label: String, selected: Boolean, action: () -> Unit): TextView {
            val t = tv(label, 13f, if (selected) dark else muted)
            t.gravity = Gravity.CENTER
            t.background = rounded(if (selected) 0xFFEAF3FF.toInt() else 0x332B5A91, 3)
            t.layoutParams = LinearLayout.LayoutParams(dp(150), dp(34))
            t.setOnClickListener { action() }
            return t
        }
        tabs.addView(tab("HOME", true) { })
        val extras = tab("EXTRAS", false) { showExtras() }
        (extras.layoutParams as LinearLayout.LayoutParams).leftMargin = dp(3)
        tabs.addView(extras)
        page.addView(tabs)

        // três grandes cartões horizontais como no menu de PES 2017
        val cards = LinearLayout(this)
        cards.orientation = LinearLayout.HORIZONTAL
        cards.gravity = Gravity.CENTER
        cards.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)

        fun imageCard(title: String, subtitle: String, asset: String, selected: Boolean,
                      action: () -> Unit): LinearLayout {
            val shell = LinearLayout(this)
            shell.orientation = LinearLayout.VERTICAL
            shell.background = rounded(if (selected) 0xFF176FE0.toInt() else 0xFFE7EEF7.toInt(), 4)
            shell.clipToOutline = true
            shell.isClickable = true
            shell.isFocusable = true
            shell.setOnClickListener { action() }
            shell.isFocusableInTouchMode = true
            shell.setOnFocusChangeListener { _, _ -> refreshMenuSelection() }
            menuCards.add(shell)
            menuActions.add(action)
            val lp = LinearLayout.LayoutParams(0, -1, 1f)
            lp.setMargins(dp(5), dp(3), dp(5), dp(3))
            shell.layoutParams = lp

            val image = ImageView(this)
            image.scaleType = ImageView.ScaleType.CENTER_CROP
            try { image.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(assets.open(asset), null)) }
            catch (_: Exception) { image.setBackgroundColor(0xFF244D86.toInt()) }
            shell.addView(image, LinearLayout.LayoutParams(-1, 0, 1.05f))

            val body = LinearLayout(this)
            body.orientation = LinearLayout.VERTICAL
            body.setPadding(dp(12), dp(10), dp(10), dp(10))
            body.setBackgroundColor(if (selected) 0xFF176FE0.toInt() else 0xFFE7EEF7.toInt())
            body.addView(tv(title, 16f, if (selected) white else 0xFF172B45.toInt()))
            val desc = tv(subtitle, 10f, if (selected) 0xFFE0ECFF.toInt() else 0xFF52647A.toInt(), false)
            desc.setPadding(0, dp(5), 0, 0)
            body.addView(desc)
            shell.addView(body, LinearLayout.LayoutParams(-1, 0, 0.9f))
            return shell
        }

        cards.addView(imageCard("SF LEAGUE", "Entre em campo e dispute partidas contra a CPU.", "neymar.png", true) { startGame(true) })
        cards.addView(imageCard("PARTIDA EXIBIÇÃO", "Jogue uma partida local com dois jogadores.", "team_barca.png", false) { startGame(false) })
        cards.addView(imageCard("TREINO", "Veja os controles e pratique os comandos.", "team_bayern.png", false) { showControls() })
        page.addView(cards)

        val hint = tv("ℹ  Escolha um modo para começar sua próxima partida.", 10f, 0xFFD5E7FF.toInt(), false)
        hint.setPadding(dp(4), dp(5), 0, dp(3))
        page.addView(hint, LinearLayout.LayoutParams(-1, dp(25)))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setPadding(dp(8), dp(5), dp(8), dp(5))
        bottom.background = rounded(0x55203F70, 4)
        val help = tv("▣  CONTROLES", 11f, white)
        help.setPadding(dp(8), dp(5), dp(18), dp(5))
        help.setOnClickListener { showControls() }
        bottom.addView(help)
        val time = tv("TEMPO  2:00", 11f, white)
        time.setPadding(dp(10), dp(5), dp(10), dp(5))
        time.setOnClickListener { cycleTime() }
        bottom.addView(time)
        timeChip = time
        timeText = tv("2:00", 1f, white) // mantido para atualizar junto com a duração
        bottom.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val exit = tv("SAIR  ✕", 11f, white)
        exit.setPadding(dp(12), dp(5), dp(8), dp(5))
        exit.setOnClickListener { finish() }
        bottom.addView(exit)
        page.addView(bottom, LinearLayout.LayoutParams(-1, dp(42)))

        updateTime()
        root.post { refreshMenuSelection() }
        return root
    }

    private fun refreshMenuSelection() {
        if (menuCards.isEmpty()) return
        menuCards.forEachIndexed { index, card ->
            val selected = index == menuSelection
            val bg = rounded(if (selected) 0xFF176FE0.toInt() else 0xFFE7EEF7.toInt(), 4)
            bg.setStroke(dp(if (selected) 3 else 1), if (selected) 0xFFFFD54F.toInt() else 0x66516B8A)
            card.background = bg
        }
    }

    private fun moveMenuSelection(direction: Int) {
        if (menuCards.isEmpty()) return
        menuSelection = (menuSelection + direction + menuCards.size) % menuCards.size
        refreshMenuSelection()
    }

    private fun confirmMenuSelection() {
        if (game.state == Game.MENU && menuSelection in menuActions.indices) menuActions[menuSelection].invoke()
    }

    private fun showExtras() {
        AlertDialog.Builder(this)
            .setTitle("SF 02 • Extras")
            .setItems(arrayOf("Controles", "Créditos", "Voltar ao menu")) { _, which ->
                when (which) {
                    0 -> showControls()
                    1 -> showCredits()
                    else -> { }
                }
            }
            .show()
    }

    private fun cycleTime() {
        timeIdx = (timeIdx + 1) % times.size
        updateTime()
    }

    private fun updateTime() {
        val label = (times[timeIdx] / 60).toString() + ":00"
        timeChip.text = "TEMPO  $label"
        timeText.text = label
    }

    private fun showControls() {
        AlertDialog.Builder(this)
            .setTitle("Controles")
            .setMessage("Toque: J1 joga no lado esquerdo da tela e J2 no lado direito. Arrasta o dedo pra correr e segura CHUTAR pra carregar a forca.\n\nControle Xbox ou PS5: analogico/direcional corre, A/X (ou R1/R2) chuta. O 1o controle conectado e o J1 (vermelho) e o 2o e o J2 (azul).\n\nModelo 3D: sulavkhdka (CC BY 4.0).")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showCredits() {
        AlertDialog.Builder(this)
            .setTitle("Creditos")
            .setMessage("Modelo 3D: \"Neymar 3d model\" por sulavkhdka (CC BY 4.0).")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun startGame(ai: Boolean) {
        game.matchSeconds = times[timeIdx]
        hud.reset()
        game.enterTeamSelect(ai)
        menu.visibility = View.GONE
        hud.visibility = View.VISIBLE
    }

    private fun showMenu() {
        hud.reset()
        game.state = Game.MENU
        hud.visibility = View.GONE
        menu.visibility = View.VISIBLE
        menuSelection = 0
        refreshMenuSelection()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (game.state != Game.MENU) showMenu() else finish()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
        val ids = InputDevice.getDeviceIds().toList().sorted()
        game.retainPads(ids)
        for (id in ids) registerPad(id)
        val im = getSystemService(Context.INPUT_SERVICE) as InputManager
        im.registerInputDeviceListener(padListener, null)
    }

    override fun onPause() {
        super.onPause()
        glView.onPause()
        val im = getSystemService(Context.INPUT_SERVICE) as InputManager
        im.unregisterInputDeviceListener(padListener)
    }

    // ------------------------------------------------------------ controles Xbox / PS5

    private val padListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) { registerPad(deviceId) }
        override fun onInputDeviceRemoved(deviceId: Int) {
            game.removePad(deviceId)
            game.clearPadState()
        }
        override fun onInputDeviceChanged(deviceId: Int) {}
    }

    private fun isPadDevice(d: InputDevice?): Boolean {
        if (d == null || d.isVirtual) return false
        val s = d.sources
        return (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }

    private fun padCanPick(p: Int): Boolean = p == game.selecting || !game.padFor(game.selecting)

    private fun registerPad(id: Int) {
        val d = InputDevice.getDevice(id)
        if (isPadDevice(d)) game.addPad(id, d?.name ?: "Controle")
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val s = e.source
        val fromPad = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (e.keyCode == KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e)
        val down = e.action == KeyEvent.ACTION_DOWN
        val first = down && e.repeatCount == 0

        // Navegacao do menu principal: teclado e controle.
        if (game.state == Game.MENU) {
            if (fromPad) registerPad(e.deviceId)
            if (first) when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_W -> { moveMenuSelection(-1); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_DOWN,
                KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_S -> { moveMenuSelection(1); return true }
                KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_START,
                KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
                KeyEvent.KEYCODE_SPACE -> { confirmMenuSelection(); return true }
            }
            if (fromPad) return true
            return super.dispatchKeyEvent(e)
        }
        if (!fromPad) return super.dispatchKeyEvent(e)
        registerPad(e.deviceId)
        val p = game.padIndex(e.deviceId)
        if (p < 0 || p > 1) return true
        when (e.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
            KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_BUTTON_L1 -> {
                game.kickBtn[p] = down
                if (first && e.keyCode == KeyEvent.KEYCODE_BUTTON_A) {
                    if (game.state == Game.CONTROLS || game.state == Game.END) game.pendingStart = true
                    else if (game.state == Game.TEAMSEL && padCanPick(p)) game.confirmTeam()
                }
            }
            KeyEvent.KEYCODE_BUTTON_B -> {
                game.kickBtn[p] = down
                if (first && game.state == Game.END) showMenu()
                else if (first && game.state == Game.TEAMSEL && padCanPick(p)) {
                    if (game.backTeam()) showMenu()
                }
            }
            KeyEvent.KEYCODE_BUTTON_START -> {
                if (first && (game.state == Game.CONTROLS || game.state == Game.END)) game.pendingStart = true
                else if (first && game.state == Game.TEAMSEL && padCanPick(p)) game.confirmTeam()
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                game.keyDX[p] = if (down) -1f else 0f
                if (first && game.state == Game.TEAMSEL && padCanPick(p)) game.moveCursor(-1)
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                game.keyDX[p] = if (down) 1f else 0f
                if (first && game.state == Game.TEAMSEL && padCanPick(p)) game.moveCursor(1)
            }
            KeyEvent.KEYCODE_DPAD_UP -> game.keyDY[p] = if (down) -1f else 0f
            KeyEvent.KEYCODE_DPAD_DOWN -> game.keyDY[p] = if (down) 1f else 0f
            else -> {}
        }
        return true
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            e.action == MotionEvent.ACTION_MOVE) {
            registerPad(e.deviceId)
            val p = game.padIndex(e.deviceId)
            if (p < 0 || p > 1) return true
            var x = e.getAxisValue(MotionEvent.AXIS_X)
            var y = e.getAxisValue(MotionEvent.AXIS_Y)
            if (Math.abs(x) < 0.2f) x = 0f
            if (Math.abs(y) < 0.2f) y = 0f
            game.stickX[p] = x
            game.stickY[p] = y
            game.hatX[p] = e.getAxisValue(MotionEvent.AXIS_HAT_X)
            game.hatY[p] = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val hx = game.hatX[p]
            val dirNow = if (x < -0.6f || hx < -0.5f) -1 else if (x > 0.6f || hx > 0.5f) 1 else 0
            if (dirNow != 0 && dirNow != lastDir[p] && game.state == Game.TEAMSEL && padCanPick(p)) {
                game.moveCursor(if (dirNow < 0) -1 else 1)
            }
            lastDir[p] = dirNow
            val t = Math.max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
            game.kickTrig[p] = t > 0.5f
            return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }
}
