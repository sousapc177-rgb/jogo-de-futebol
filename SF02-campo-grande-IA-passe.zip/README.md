# SF02 - atualizacao de campo e IA

- Campo ampliado (dimensoes do gramado e camera ajustadas).
- Modelos dos 22 jogadores maiores, reutilizando o mesmo modelo e as texturas existentes.
- 10 companheiros por lado agora possuem posicao e velocidade persistentes e movimentacao por IA para apoiar/pressionar a jogada.
- Botao PASSE reposicionado e ampliado no HUD; passe rasteiro com mais alcance.

Observacao: nesta versao, o joystick ainda controla o jogador principal de cada lado. Os outros 20 jogadores se movimentam por IA simples. A troca automatica do jogador controlado para o companheiro que recebe o passe e a IA completa de goleiros/posicoes ainda nao estao implementadas.
