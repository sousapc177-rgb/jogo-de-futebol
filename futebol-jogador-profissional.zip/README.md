# Neymar Futebol
Futebol 1x1 para 2 jogadores no mesmo celular (Kotlin + OpenGL ES 2.0).
Modelo 3D: "Professional Soccer Standing" por Innerscene (CC0 1.0).
