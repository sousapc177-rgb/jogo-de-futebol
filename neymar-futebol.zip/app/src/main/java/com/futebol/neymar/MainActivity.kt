package com.futebol.neymar

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val game = Game()
    private lateinit var glView: GLSurfaceView
    private lateinit var hud: HudView
    private lateinit var menu: View
    private lateinit var timeBtn: TextView
    private val times = intArrayOf(60, 120, 180)
    private var timeIdx = 1

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val root = FrameLayout(this)

        hud = HudView(this, game) { showMenu() }
        hud.visibility = View.GONE

        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        glView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        glView.setRenderer(GameRenderer(this, game, hud))

        menu = buildMenu()

        root.addView(glView, FrameLayout.LayoutParams(-1, -1))
        root.addView(hud, FrameLayout.LayoutParams(-1, -1))
        root.addView(menu, FrameLayout.LayoutParams(resources.displayMetrics.widthPixels * 55 / 100, -1))
        setContentView(root)
    }

    private fun btn(text: String, color: Int, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.cornerRadius = dp(28).toFloat()
        bg.setColor(color)
        t.background = bg
        val lp = LinearLayout.LayoutParams(dp(280), dp(54))
        lp.topMargin = dp(10)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildMenu(): View {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER_VERTICAL
        panel.setPadding(dp(36), dp(12), dp(24), dp(12))
        panel.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xF00B2A12.toInt(), 0xF00B2A12.toInt(), 0x000B2A12)
        )

        val title = TextView(this)
        title.text = "NEYMAR\nFUTEBOL"
        title.setTextColor(0xFFFFD500.toInt())
        title.textSize = 38f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setShadowLayer(8f, 0f, 4f, 0xFF000000.toInt())
        panel.addView(title)

        val sub = TextView(this)
        sub.text = "1 contra 1  -  2 jogadores no mesmo celular"
        sub.setTextColor(Color.WHITE)
        sub.textSize = 14f
        sub.setPadding(0, dp(4), 0, dp(10))
        panel.addView(sub)

        panel.addView(btn("JOGAR", 0xFF2E9E3F.toInt()) { startGame() })
        timeBtn = btn("", 0xFF1E6FBF.toInt()) {
            timeIdx = (timeIdx + 1) % times.size
            updateTimeBtn()
        }
        updateTimeBtn()
        panel.addView(timeBtn)
        panel.addView(btn("SAIR", 0xFF8A2D2D.toInt()) { finish() })

        val how = TextView(this)
        how.text = "J1 = lado esquerdo da tela, J2 = lado direito.\nArrasta o dedo pra correr e toca em CHUTAR."
        how.setTextColor(0xCCFFFFFF.toInt())
        how.textSize = 12f
        how.setPadding(0, dp(14), 0, 0)
        panel.addView(how)

        val credit = TextView(this)
        credit.text = "Modelo 3D: sulavkhdka (CC BY 4.0)"
        credit.setTextColor(0x88FFFFFF.toInt())
        credit.textSize = 10f
        credit.setPadding(0, dp(6), 0, 0)
        panel.addView(credit)
        return panel
    }

    private fun updateTimeBtn() {
        val s = times[timeIdx]
        timeBtn.text = "TEMPO: " + (s / 60) + ":00"
    }

    private fun startGame() {
        game.matchSeconds = times[timeIdx]
        hud.reset()
        game.pendingStart = true
        menu.visibility = View.GONE
        hud.visibility = View.VISIBLE
    }

    private fun showMenu() {
        hud.reset()
        game.state = Game.MENU
        hud.visibility = View.GONE
        menu.visibility = View.VISIBLE
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (game.state != Game.MENU) showMenu() else finish()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glView.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }
}
