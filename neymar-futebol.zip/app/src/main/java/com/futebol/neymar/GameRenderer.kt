package com.futebol.neymar

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.View
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Malha com VBO: posicao(3) + normal(3) + extra(2 = uv, 3 = cor) */
class Mesh(data: FloatArray, private val extra: Int, indices: ShortArray?) {
    private val stride = (6 + extra) * 4
    private val vbo = IntArray(1)
    private val ibo = IntArray(1)
    private val indexed = indices != null
    val count: Int

    init {
        GLES20.glGenBuffers(1, vbo, 0)
        val fb = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(data)
        fb.position(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, fb, GLES20.GL_STATIC_DRAW)
        if (indices != null) {
            GLES20.glGenBuffers(1, ibo, 0)
            val sb = ByteBuffer.allocateDirect(indices.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
            sb.put(indices)
            sb.position(0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo[0])
            GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, indices.size * 2, sb, GLES20.GL_STATIC_DRAW)
            count = indices.size
        } else {
            count = data.size / (6 + extra)
        }
    }

    fun draw(pLoc: Int, nLoc: Int, eLoc: Int) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo[0])
        GLES20.glEnableVertexAttribArray(pLoc)
        GLES20.glVertexAttribPointer(pLoc, 3, GLES20.GL_FLOAT, false, stride, 0)
        GLES20.glEnableVertexAttribArray(nLoc)
        GLES20.glVertexAttribPointer(nLoc, 3, GLES20.GL_FLOAT, false, stride, 12)
        GLES20.glEnableVertexAttribArray(eLoc)
        GLES20.glVertexAttribPointer(eLoc, extra, GLES20.GL_FLOAT, false, stride, 24)
        if (indexed) {
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo[0])
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, count, GLES20.GL_UNSIGNED_SHORT, 0)
        } else {
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
        }
    }
}

/** Construtor de malhas simples (cores por vertice) */
class MB {
    var a = FloatArray(8192)
    var n = 0

    fun v(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float, c: FloatArray) {
        if (n + 9 > a.size) a = a.copyOf(a.size * 2)
        a[n++] = x; a[n++] = y; a[n++] = z
        a[n++] = nx; a[n++] = ny; a[n++] = nz
        a[n++] = c[0]; a[n++] = c[1]; a[n++] = c[2]
    }

    fun quad(
        x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float, x3: Float, y3: Float, z3: Float,
        nx: Float, ny: Float, nz: Float, c: FloatArray
    ) {
        v(x0, y0, z0, nx, ny, nz, c); v(x1, y1, z1, nx, ny, nz, c); v(x2, y2, z2, nx, ny, nz, c)
        v(x0, y0, z0, nx, ny, nz, c); v(x2, y2, z2, nx, ny, nz, c); v(x3, y3, z3, nx, ny, nz, c)
    }

    fun quadY(x0: Float, z0: Float, x1: Float, z1: Float, y: Float, c: FloatArray) {
        quad(x0, y, z0, x1, y, z0, x1, y, z1, x0, y, z1, 0f, 1f, 0f, c)
    }

    fun line(x1: Float, z1: Float, x2: Float, z2: Float, w: Float, c: FloatArray) {
        val dx = x2 - x1
        val dz = z2 - z1
        val len = hypot(dx, dz)
        if (len < 0.0001f) return
        val px = -dz / len * w / 2f
        val pz = dx / len * w / 2f
        val y = 0.03f
        quad(x1 - px, y, z1 - pz, x1 + px, y, z1 + pz, x2 + px, y, z2 + pz, x2 - px, y, z2 - pz, 0f, 1f, 0f, c)
    }

    fun box(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, c: FloatArray) {
        val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
        val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
        val z0 = cz - sz / 2f; val z1 = cz + sz / 2f
        quad(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0f, 1f, 0f, c)
        quad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0f, 0f, 1f, c)
        quad(x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, 0f, 0f, -1f, c)
        quad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1f, 0f, 0f, c)
        quad(x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, 1f, 0f, 0f, c)
    }

    fun toMesh(): Mesh = Mesh(a.copyOf(n), 3, null)
}

class GameRenderer(
    private val ctx: Context,
    private val game: Game,
    private val hud: View
) : GLSurfaceView.Renderer {

    private val VS_C = """
        uniform mat4 uMVP; uniform mat4 uModel;
        attribute vec3 aPos; attribute vec3 aNorm; attribute vec3 aCol;
        varying vec3 vCol; varying float vL;
        void main() {
            gl_Position = uMVP * vec4(aPos, 1.0);
            vec3 n = normalize((uModel * vec4(aNorm, 0.0)).xyz);
            vL = 0.55 + 0.5 * max(dot(n, normalize(vec3(0.4, 0.9, 0.5))), 0.0);
            vCol = aCol;
        }
    """.trimIndent()
    private val FS_C = """
        precision mediump float;
        uniform vec3 uTint; uniform float uAlpha;
        varying vec3 vCol; varying float vL;
        void main() { gl_FragColor = vec4(vCol * uTint * vL, uAlpha); }
    """.trimIndent()
    private val VS_T = """
        uniform mat4 uMVP; uniform mat4 uModel;
        attribute vec3 aPos; attribute vec3 aNorm; attribute vec2 aUV;
        varying vec2 vUV; varying float vL;
        void main() {
            gl_Position = uMVP * vec4(aPos, 1.0);
            vec3 n = normalize((uModel * vec4(aNorm, 0.0)).xyz);
            vL = 0.6 + 0.55 * max(dot(n, normalize(vec3(0.4, 0.9, 0.5))), 0.0);
            vUV = aUV;
        }
    """.trimIndent()
    private val FS_T = """
        precision mediump float;
        uniform sampler2D uTex;
        varying vec2 vUV; varying float vL;
        void main() { gl_FragColor = vec4(texture2D(uTex, vUV).rgb * vL, 1.0); }
    """.trimIndent()

    private var cProg = 0
    private var tProg = 0
    private var cMVP = 0; private var cModel = 0; private var cTint = 0; private var cAlpha = 0
    private var caPos = 0; private var caNorm = 0; private var caCol = 0
    private var tMVP = 0; private var tModel = 0; private var tTex = 0
    private var taPos = 0; private var taNorm = 0; private var taUV = 0

    private lateinit var scene: Mesh
    private lateinit var ball: Mesh
    private lateinit var disc: Mesh
    private lateinit var neymar: Mesh
    private var texId = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val tmp = FloatArray(16)
    private val tmp2 = FloatArray(16)
    private val ballRot = FloatArray(16)
    private var aspect = 2f
    private var last = 0L

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.53f, 0.78f, 0.95f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)

        cProg = link(VS_C, FS_C)
        cMVP = GLES20.glGetUniformLocation(cProg, "uMVP")
        cModel = GLES20.glGetUniformLocation(cProg, "uModel")
        cTint = GLES20.glGetUniformLocation(cProg, "uTint")
        cAlpha = GLES20.glGetUniformLocation(cProg, "uAlpha")
        caPos = GLES20.glGetAttribLocation(cProg, "aPos")
        caNorm = GLES20.glGetAttribLocation(cProg, "aNorm")
        caCol = GLES20.glGetAttribLocation(cProg, "aCol")

        tProg = link(VS_T, FS_T)
        tMVP = GLES20.glGetUniformLocation(tProg, "uMVP")
        tModel = GLES20.glGetUniformLocation(tProg, "uModel")
        tTex = GLES20.glGetUniformLocation(tProg, "uTex")
        taPos = GLES20.glGetAttribLocation(tProg, "aPos")
        taNorm = GLES20.glGetAttribLocation(tProg, "aNorm")
        taUV = GLES20.glGetAttribLocation(tProg, "aUV")

        scene = buildScene()
        ball = buildBall()
        disc = buildDisc()
        neymar = loadNeymar()
        texId = loadTexture()
        Matrix.setIdentityM(ballRot, 0)
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        aspect = w.toFloat() / h.toFloat()
    }

    // ------------------------------------------------------------ construcao

    private fun buildScene(): Mesh {
        val b = MB()
        val hl = Game.HL
        val hw = Game.HW
        val gw = Game.GOALW
        val gd = Game.GOALD
        val gh = Game.GOALH

        b.quadY(-45f, -35f, 45f, 35f, -0.03f, floatArrayOf(0.10f, 0.32f, 0.14f))
        val g1 = floatArrayOf(0.20f, 0.56f, 0.24f)
        val g2 = floatArrayOf(0.17f, 0.50f, 0.21f)
        for (i in 0 until 12) {
            val x0 = -hl + i * 2f
            b.quadY(x0, -hw, x0 + 2f, hw, 0f, if (i % 2 == 0) g1 else g2)
        }

        val wh = floatArrayOf(0.95f, 0.95f, 0.95f)
        val lw = 0.12f
        b.line(-hl, -hw, hl, -hw, lw, wh)
        b.line(hl, -hw, hl, hw, lw, wh)
        b.line(hl, hw, -hl, hw, lw, wh)
        b.line(-hl, hw, -hl, -hw, lw, wh)
        b.line(0f, -hw, 0f, hw, lw, wh)
        val seg = 40
        for (i in 0 until seg) {
            val a0 = 2f * Game.PIF * i / seg
            val a1 = 2f * Game.PIF * (i + 1) / seg
            b.line(2.2f * cos(a0), 2.2f * sin(a0), 2.2f * cos(a1), 2.2f * sin(a1), lw, wh)
        }
        for (s in intArrayOf(-1, 1)) {
            val xe = s * hl
            val xp = s * (hl - 3.5f)
            b.line(xe, -4.2f, xp, -4.2f, lw, wh)
            b.line(xp, -4.2f, xp, 4.2f, lw, wh)
            b.line(xp, 4.2f, xe, 4.2f, lw, wh)
            val xg = s * (hl - 1.4f)
            b.line(xe, -3f, xg, -3f, lw, wh)
            b.line(xg, -3f, xg, 3f, lw, wh)
            b.line(xg, 3f, xe, 3f, lw, wh)
        }

        // gols
        val gray = floatArrayOf(0.6f, 0.6f, 0.6f)
        val net = floatArrayOf(0.85f, 0.85f, 0.85f)
        val post = 0.14f
        for (s in intArrayOf(-1, 1)) {
            val gx = s * hl
            val bxk = s * (hl + gd)
            for (zz in floatArrayOf(-gw, gw)) {
                b.box(gx, gh / 2f, zz, post, gh, post, wh)
                b.box(bxk, gh / 2f, zz, post * 0.7f, gh, post * 0.7f, gray)
            }
            b.box(gx, gh, 0f, post, post, gw * 2f + post, wh)
            var z = -gw
            while (z <= gw + 0.01f) { b.box(bxk, gh / 2f, z, 0.03f, gh, 0.03f, net); z += 0.4f }
            var y = 0f
            while (y <= gh + 0.01f) { b.box(bxk, y, 0f, 0.03f, 0.03f, gw * 2f, net); y += 0.4f }
            for (zz in floatArrayOf(-gw, gw)) {
                var x = 0f
                while (x <= gd + 0.01f) { b.box(gx + s * x, gh / 2f, zz, 0.03f, gh, 0.03f, net); x += 0.5f }
                var yy = 0f
                while (yy <= gh + 0.01f) { b.box(gx + s * gd / 2f, yy, zz, gd, 0.03f, 0.03f, net); yy += 0.4f }
            }
            var zr = -gw
            while (zr <= gw + 0.01f) { b.box(gx + s * gd / 2f, gh, zr, gd, 0.03f, 0.03f, net); zr += 0.6f }
        }
        return b.toMesh()
    }

    private fun buildBall(): Mesh {
        val b = MB()
        val r = Game.BR
        val nlat = 10
        val nlon = 14
        val white = floatArrayOf(0.97f, 0.97f, 0.97f)
        val dark = floatArrayOf(0.08f, 0.08f, 0.08f)
        for (i in 0 until nlat) {
            val t0 = Game.PIF * i / nlat
            val t1 = Game.PIF * (i + 1) / nlat
            for (j in 0 until nlon) {
                val f0 = 2f * Game.PIF * j / nlon
                val f1 = 2f * Game.PIF * (j + 1) / nlon
                val c = if ((i + j) % 2 == 0) white else dark
                val ax = sin(t0) * cos(f0); val ay = cos(t0); val az = sin(t0) * sin(f0)
                val bx = sin(t0) * cos(f1); val bz = sin(t0) * sin(f1)
                val cx = sin(t1) * cos(f1); val cy = cos(t1); val cz = sin(t1) * sin(f1)
                val dx = sin(t1) * cos(f0); val dz = sin(t1) * sin(f0)
                b.v(ax * r, ay * r, az * r, ax, ay, az, c)
                b.v(bx * r, ay * r, bz * r, bx, ay, bz, c)
                b.v(cx * r, cy * r, cz * r, cx, cy, cz, c)
                b.v(ax * r, ay * r, az * r, ax, ay, az, c)
                b.v(cx * r, cy * r, cz * r, cx, cy, cz, c)
                b.v(dx * r, cy * r, dz * r, dx, cy, dz, c)
            }
        }
        return b.toMesh()
    }

    private fun buildDisc(): Mesh {
        val b = MB()
        val w = floatArrayOf(1f, 1f, 1f)
        val seg = 24
        for (i in 0 until seg) {
            val a0 = 2f * Game.PIF * i / seg
            val a1 = 2f * Game.PIF * (i + 1) / seg
            b.v(0f, 0f, 0f, 0f, 1f, 0f, w)
            b.v(cos(a0), 0f, sin(a0), 0f, 1f, 0f, w)
            b.v(cos(a1), 0f, sin(a1), 0f, 1f, 0f, w)
        }
        return b.toMesh()
    }

    private fun loadNeymar(): Mesh {
        val bytes = ctx.assets.open("neymar.bin").use { it.readBytes() }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val nV = bb.getInt(0)
        val nI = bb.getInt(4)
        val fa = FloatArray(nV * 8)
        bb.position(8)
        bb.asFloatBuffer().get(fa)
        val ia = ShortArray(nI)
        bb.position(8 + nV * 32)
        bb.asShortBuffer().get(ia)
        return Mesh(fa, 2, ia)
    }

    private fun loadTexture(): Int {
        val bmp = ctx.assets.open("neymar.png").use { BitmapFactory.decodeStream(it) }
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        bmp.recycle()
        return t[0]
    }

    // ------------------------------------------------------------ desenho

    private fun drawColor(m: Mesh, r: Float, g: Float, b: Float, a: Float) {
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(cMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(cModel, 1, false, model, 0)
        GLES20.glUniform3f(cTint, r, g, b)
        GLES20.glUniform1f(cAlpha, a)
        m.draw(caPos, caNorm, caCol)
    }

    private fun drawPlayer(x: Float, y: Float, z: Float, yaw: Float, lean: Float, roll: Float, scale: Float) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.rotateM(model, 0, yaw, 0f, 1f, 0f)
        Matrix.rotateM(model, 0, lean, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, roll, 0f, 0f, 1f)
        Matrix.scaleM(model, 0, scale, scale, scale)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(tMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(tModel, 1, false, model, 0)
        neymar.draw(taPos, taNorm, taUV)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        game.update(dt)

        // rotacao da bola
        val sp = hypot(game.bvx, game.bvz)
        if (sp > 0.05f && game.by <= Game.BR + 0.05f && game.state != Game.MENU) {
            val deg = sp * dt / Game.BR * 180f / Game.PIF
            Matrix.setRotateM(tmp, 0, deg, game.bvz / sp, 0f, -game.bvx / sp)
            Matrix.multiplyMM(tmp2, 0, tmp, 0, ballRot, 0)
            System.arraycopy(tmp2, 0, ballRot, 0, 16)
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val menu = game.state == Game.MENU
        if (menu) {
            Matrix.perspectiveM(proj, 0, 38f, aspect, 1f, 80f)
            Matrix.setLookAtM(view, 0, -0.5f, 1.7f, 6.5f, -0.5f, 0.9f, 0f, 0f, 1f, 0f)
        } else {
            val cx = game.bx * 0.25f
            Matrix.perspectiveM(proj, 0, 42f, aspect, 1f, 80f)
            Matrix.setLookAtM(view, 0, cx, 13f, 14f, cx, 0f, 1f, 0f, 1f, 0f)
        }
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        // campo + bola
        GLES20.glUseProgram(cProg)
        Matrix.setIdentityM(model, 0)
        drawColor(scene, 1f, 1f, 1f, 1f)
        if (!menu) {
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, game.bx, game.by, game.bz)
            Matrix.multiplyMM(tmp, 0, model, 0, ballRot, 0)
            System.arraycopy(tmp, 0, model, 0, 16)
            drawColor(ball, 1f, 1f, 1f, 1f)
        }

        // jogadores
        GLES20.glUseProgram(tProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glUniform1i(tTex, 0)
        if (menu) {
            drawPlayer(1.2f, 0f, 0f, game.time * 50f, 0f, 0f, 1.5f)
            drawPlayer(3.3f, 0f, 0f, -game.time * 50f + 90f, 0f, 0f, 1.5f)
        } else {
            for (p in 0..1) {
                val speed = hypot(game.vx[p], game.vz[p])
                val frac = min(1f, speed / Game.SPEED)
                var bob = abs(sin(game.runPhase[p])) * 0.07f * frac
                val roll = sin(game.runPhase[p]) * 6f * frac
                var lean = 10f * frac
                if (game.kickAnim[p] > 0f) {
                    lean += 25f * sin(game.kickAnim[p] / 0.3f * Game.PIF)
                }
                if (game.state == Game.GOAL && game.lastScorer == p) {
                    bob = abs(sin(game.time * 9f)) * 0.45f
                    lean = -8f
                }
                drawPlayer(game.px[p], bob, game.pz[p], game.yaw[p], lean, roll, 1.25f)
            }
        }

        // sombras e aneis dos times (transparentes)
        if (!menu) {
            GLES20.glUseProgram(cProg)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            GLES20.glDepthMask(false)
            for (p in 0..1) {
                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, game.px[p], 0.04f, game.pz[p])
                Matrix.scaleM(model, 0, 0.62f, 1f, 0.62f)
                if (p == 0) drawColor(disc, 0.95f, 0.15f, 0.15f, 0.75f)
                else drawColor(disc, 0.15f, 0.45f, 1f, 0.75f)
            }
            val sc = Game.BR * (1f + game.by * 0.15f)
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, game.bx, 0.05f, game.bz)
            Matrix.scaleM(model, 0, sc, 1f, sc)
            drawColor(disc, 0f, 0f, 0f, 0.35f)
            GLES20.glDepthMask(true)
            GLES20.glDisable(GLES20.GL_BLEND)
        }

        hud.postInvalidate()
    }
}
