# SF02 - times adicionais

Esta versão parte do SF02 clássico com a partida original de dois jogadores.
Foram adicionados Inter de Milão e Juventus à seleção de times, com escudos e texturas de uniforme próprios.
Não inclui modo 11v11 nem altera o número de jogadores em campo.

Build: `gradle assembleDebug`
