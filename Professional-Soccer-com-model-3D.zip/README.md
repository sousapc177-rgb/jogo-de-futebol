# Professional Soccer

Jogo de futebol 1x1 para dois jogadores no mesmo celular, feito em Kotlin + OpenGL ES 2.0.

O modelo de jogador original foi substituido pelo modelo 3D Professional Soccer. O jogo usa animacao procedural no shader para corrida, chute e movimento idle no menu. O modelo fornecido e estatico (nao possui clips de animacao embutidos); os movimentos sao aplicados em tempo real pelo renderizador.
